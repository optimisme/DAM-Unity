using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.U2D.Sprites;
using UnityEngine;

public static class Match3ArtBuilder
{
    const string Root = "Assets/Match3";
    [MenuItem("Tools/Match3/Preparar sprites i animacions")]
    public static void Build()
    {
        string path = Root + "/Textures/Gemmes.png";
        var importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (!importer) throw new FileNotFoundException("Importa Match3.zip: falta " + path);
        importer.textureType = TextureImporterType.Sprite;
        importer.spriteImportMode = SpriteImportMode.Multiple;
        importer.spritePixelsPerUnit = 256;
        importer.filterMode = FilterMode.Bilinear;
        importer.textureCompression = TextureImporterCompression.Uncompressed;
        importer.maxTextureSize = 2048;
        importer.mipmapEnabled = false;
        importer.alphaIsTransparency = true;
        var settings = new TextureImporterSettings();
        importer.ReadTextureSettings(settings);
        settings.spriteMeshType = SpriteMeshType.FullRect;
        importer.SetTextureSettings(settings);
        importer.SaveAndReimport();
        var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        if (texture.width != 1024 || texture.height != 1536)
            throw new System.ArgumentException("Gemmes.png ha de fer 1024 × 1536 píxels.");
        var factory = new SpriteDataProviderFactories(); factory.Init();
        var provider = factory.GetSpriteEditorDataProviderFromObject(importer);
        provider.InitSpriteEditorDataProvider();
        var previous = provider.GetSpriteRects().ToDictionary(r => r.name);
        // Rectangles mesurats sobre aquest full il·lustrat: no és una graella exacta.
        // Coordenades des de la cantonada superior esquerra, extrems inclosos.
        int[,] bounds = {
            {55,59,234,238},{302,58,481,238},{545,58,724,238},{790,58,969,238},
            {59,279,230,477},{305,279,477,478},{550,279,721,478},{793,279,965,477},
            {50,526,239,697},{297,526,485,697},{540,526,728,697},{785,526,973,697},
            {84,729,203,981},{334,729,452,981},{573,729,692,981},{819,729,938,981},
            {68,1009,221,1241},{316,1009,470,1241},{553,1009,707,1241},{804,1009,957,1241},
            {107,1340,180,1413},{298,1286,480,1466},{534,1264,735,1489},{799,1309,955,1467}
        };
        var rects = new SpriteRect[24];
        for (int row = 0; row < 6; row++)
            for (int frame = 0; frame < 4; frame++)
            {
                string name = row < 5 ? $"Gemma_{row}_{frame}" : $"Burst_{frame}";
                int i = row * 4 + frame, width = 0, height = 0;
                for (int f = 0; f < 4; f++)
                {
                    int j = row * 4 + f;
                    width = Mathf.Max(width, bounds[j, 2] - bounds[j, 0] + 1 + 16);
                    height = Mathf.Max(height, bounds[j, 3] - bounds[j, 1] + 1 + 16);
                }
                float centerX = (bounds[i, 0] + bounds[i, 2] + 1) * .5f;
                float centerY = (bounds[i, 1] + bounds[i, 3] + 1) * .5f;
                // Mateixa mida de retall a tota la fila, amb cada gemma centrada.
                var crop = new Rect(Mathf.Floor(centerX - width * .5f),
                    texture.height - Mathf.Floor(centerY - height * .5f) - height, width, height);
                rects[row * 4 + frame] = new SpriteRect
                {
                    name = name,
                    spriteID = previous.TryGetValue(name, out var old) ? old.spriteID : GUID.Generate(),
                    rect = crop,
                    alignment = SpriteAlignment.Center,
                    pivot = new Vector2(.5f, .5f)
                };
            }
        provider.SetSpriteRects(rects);
        provider.GetDataProvider<ISpriteNameFileIdDataProvider>().SetNameFileIdPairs(
            rects.Select(r => new SpriteNameFileIdPair(r.name, r.spriteID)));
        provider.Apply(); importer.SaveAndReimport();
        var sprites = AssetDatabase.LoadAllAssetsAtPath(path).OfType<Sprite>().ToDictionary(s => s.name);
        string assetPath = Root + "/GemmesSkin.asset";
        var skin = AssetDatabase.LoadAssetAtPath<Match3Skin>(assetPath);
        if (!skin) { skin = ScriptableObject.CreateInstance<Match3Skin>(); AssetDatabase.CreateAsset(skin, assetPath); }
        skin.gemFrames = Enumerable.Range(0, 20).Select(i => sprites[$"Gemma_{i / 4}_{i % 4}"]).ToArray();
        skin.burstFrames = Enumerable.Range(0, 4).Select(i => sprites[$"Burst_{i}"]).ToArray();
        skin.framesPerSecond = 6;
        EditorUtility.SetDirty(skin); AssetDatabase.SaveAssets();
        Selection.activeObject = skin;
        Debug.Log("MATCH3_ART_READY: 20 fotogrames de gemmes i 4 d'eliminació. Assigna GemmesSkin al prefab i als efectes.");
    }
}
