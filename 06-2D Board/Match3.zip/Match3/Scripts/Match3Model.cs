using System;
using System.Collections.Generic;

// Només regles i dades: no depèn de la pantalla ni dels clics.
public sealed class Match3Model
{
    public const int Size = 8;
    public const int Types = 5;
    public int[,] Cells { get; } = new int[Size, Size];
    readonly Random random;

    public struct Fall
    {
        public int X, FromY, ToY, Type;
        public bool IsNew;
    }

    public Match3Model(int seed)
    {
        random = new Random(seed);
        Generate();
    }

    public bool Inside(int x, int y) => x >= 0 && y >= 0 && x < Size && y < Size;

    public bool Adjacent(int ax, int ay, int bx, int by) =>
        Inside(ax, ay) && Inside(bx, by) && Math.Abs(ax - bx) + Math.Abs(ay - by) == 1;

    public void Swap(int ax, int ay, int bx, int by)
    {
        int value = Cells[ax, ay];
        Cells[ax, ay] = Cells[bx, by];
        Cells[bx, by] = value;
    }

    public bool CanSwap(int ax, int ay, int bx, int by)
    {
        if (!Adjacent(ax, ay, bx, by)) return false;
        Swap(ax, ay, bx, by);
        var matches = FindMatches();
        // Comprovem les peces intercanviades; una coincidència aliena no valida el moviment.
        bool valid = matches.Contains(ay * Size + ax) || matches.Contains(by * Size + bx);
        Swap(ax, ay, bx, by);
        return valid;
    }

    public bool HasMove()
    {
        for (int y = 0; y < Size; y++)
            for (int x = 0; x < Size; x++)
                if (CanSwap(x, y, x + 1, y) || CanSwap(x, y, x, y + 1)) return true;
        return false;
    }

    public HashSet<int> FindMatches()
    {
        var found = new HashSet<int>();
        for (int y = 0; y < Size; y++)
            for (int x = 0; x < Size;)
            {
                int end = x + 1;
                while (end < Size && Cells[end, y] == Cells[x, y]) end++;
                if (Cells[x, y] >= 0 && end - x >= 3)
                    for (int k = x; k < end; k++) found.Add(y * Size + k);
                x = end;
            }
        for (int x = 0; x < Size; x++)
            for (int y = 0; y < Size;)
            {
                int end = y + 1;
                while (end < Size && Cells[x, end] == Cells[x, y]) end++;
                if (Cells[x, y] >= 0 && end - y >= 3)
                    for (int k = y; k < end; k++) found.Add(k * Size + x);
                y = end;
            }
        // HashSet compta una sola vegada el centre d'una creu o d'una T.
        return found;
    }

    public void Clear(IEnumerable<int> matches)
    {
        foreach (int cell in matches) Cells[cell % Size, cell / Size] = -1;
    }

    public List<Fall> CollapseAndRefill()
    {
        var falls = new List<Fall>();
        for (int x = 0; x < Size; x++)
        {
            int destination = 0;
            for (int y = 0; y < Size; y++)
            {
                if (Cells[x, y] < 0) continue;
                int type = Cells[x, y];
                Cells[x, destination] = type;
                falls.Add(new Fall { X = x, FromY = y, ToY = destination, Type = type });
                destination++;
            }
            int spawn = Size;
            while (destination < Size)
            {
                int type = random.Next(Types);
                Cells[x, destination] = type;
                falls.Add(new Fall { X = x, FromY = spawn++, ToY = destination++, Type = type, IsNew = true });
            }
        }
        return falls;
    }

    public void Generate()
    {
        // Evitem triples inicials: només cal mirar les dues peces de l'esquerra i de sota.
        for (int attempt = 0; attempt < 100; attempt++)
        {
            for (int y = 0; y < Size; y++)
                for (int x = 0; x < Size; x++)
                {
                    var available = new List<int>();
                    for (int type = 0; type < Types; type++)
                    {
                        bool horizontal = x >= 2 && Cells[x - 1, y] == type && Cells[x - 2, y] == type;
                        bool vertical = y >= 2 && Cells[x, y - 1] == type && Cells[x, y - 2] == type;
                        if (!horizontal && !vertical) available.Add(type);
                    }
                    Cells[x, y] = available[random.Next(available.Count)];
                }
            if (HasMove()) return;
        }
        // Sortida limitada i reproduïble, sense un bucle infinit de reintents.
        for (int y = 0; y < Size; y++)
            for (int x = 0; x < Size; x++) Cells[x, y] = (x + 2 * y) % Types;
        Cells[0, 0] = 0; Cells[1, 0] = 1; Cells[2, 0] = 0; Cells[1, 1] = 0;
    }
}
