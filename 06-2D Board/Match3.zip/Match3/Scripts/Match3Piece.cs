using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Els mateixos esdeveniments de la UI funcionen amb el ratolí, sense colliders.
public sealed class Match3Piece : MonoBehaviour, IPointerDownHandler, IPointerClickHandler,
    IBeginDragHandler, IDragHandler, IEndDragHandler
{
    [SerializeField] Image gem;
    [SerializeField] Match3Skin skin;
    [SerializeField] TMP_Text number;
    [SerializeField] Image frame;
    static readonly Color32[] Colors = {
        new Color32(67, 211, 205, 255), new Color32(255, 193, 87, 255),
        new Color32(244, 120, 165, 255), new Color32(156, 143, 255, 255),
        new Color32(126, 213, 117, 255)
    };
    Match3Board board;
    int x, y, type, lastFrame = -1;
    bool selected;
    bool dragged, dragging;
    Vector2 press;
    public RectTransform Rect => (RectTransform)transform;

    public void Setup(Match3Board owner, int column, int row, int type)
    {
        board = owner; x = column; y = row;
        this.type = type;
        lastFrame = -1;
        gem.color = skin ? Color.white : Colors[type];
        if (skin) gem.sprite = skin.Gem(type, 0);
        number.text = (type + 1).ToString();
        Select(false);
    }
    public void SetCell(int column, int row) { x = column; y = row; }
    public void Select(bool selected)
    {
        this.selected = selected;
        frame.color = selected ? Color.white : new Color32(37, 51, 78, 255);
    }

    void Update()
    {
        if (!skin) return;
        // El desfasament evita que les 64 gemmes brillin alhora.
        int frameIndex = Mathf.FloorToInt((Time.unscaledTime + x * .11f + y * .07f) * skin.framesPerSecond) % Match3Skin.FramesPerGem;
        if (frameIndex != lastFrame)
        {
            gem.sprite = skin.Gem(type, frameIndex);
            lastFrame = frameIndex;
        }
        // Només animem el fill: el pare continua lliure per arrossegar-lo i eliminar-lo.
        float scale = (selected ? 1.06f : 1f) + Mathf.Sin(Time.unscaledTime * 3 + x + y) * .025f;
        gem.rectTransform.localScale = Vector3.one * scale;
    }
    public void OnPointerDown(PointerEventData e)
    {
        if (e.button == PointerEventData.InputButton.Left) dragged = false;
    }
    public void OnPointerClick(PointerEventData e)
    {
        if (e.button == PointerEventData.InputButton.Left && !dragged) board.Click(x, y);
    }
    public void OnBeginDrag(PointerEventData e)
    {
        if (e.button != PointerEventData.InputButton.Left || !board.CanInteract) return;
        dragged = dragging = true;
        board.Deselect();
        RectTransformUtility.ScreenPointToLocalPointInRectangle(board.Area, e.pressPosition, e.pressEventCamera, out press);
        Select(true);
        transform.SetAsLastSibling();
    }
    public void OnDrag(PointerEventData e)
    {
        if (!dragging) return;
        RectTransformUtility.ScreenPointToLocalPointInRectangle(board.Area, e.position, e.pressEventCamera, out var point);
        // Limitem el dibuix a una casella; encara no alterem les dades del tauler.
        Rect.anchoredPosition = board.Position(x, y) + Vector2.ClampMagnitude(point - press, Match3Board.Step);
    }
    public void OnEndDrag(PointerEventData e)
    {
        if (!dragging) return;
        dragging = false;
        Rect.anchoredPosition = board.Position(x, y);
        Select(false);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(board.Area, e.position, e.pressEventCamera, out var point);
        // Deixar anar fora del tauler cancel·la l'acció.
        if (!RectTransformUtility.RectangleContainsScreenPoint(board.Area, e.position, e.pressEventCamera)) return;
        Vector2 delta = point - press;
        if (delta.magnitude < Match3Board.Step * .35f) return;
        int dx = 0, dy = 0;
        if (Mathf.Abs(delta.x) >= Mathf.Abs(delta.y)) dx = delta.x > 0 ? 1 : -1;
        else dy = delta.y > 0 ? 1 : -1;
        board.TryMove(x, y, x + dx, y + dy);
        // dragged continua cert fins al proper PointerDown: no executem també un clic.
    }
    void OnApplicationFocus(bool focus)
    {
        if (focus || !dragging) return;
        dragging = false;
        Rect.anchoredPosition = board.Position(x, y);
        Select(false);
    }
}
