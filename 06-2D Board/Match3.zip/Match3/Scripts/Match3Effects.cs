using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// UI sobre el tauler, sense colliders ni elements que interceptin el ratolí.
public sealed class Match3Effects : MonoBehaviour
{
    [SerializeField] RectTransform overlay;
    [SerializeField] Match3Skin skin;
    [SerializeField, Range(.15f, 1f)] float duration = .36f;
    public int ActiveBursts => overlay ? overlay.childCount : 0;

    public void PlayAt(RectTransform piece)
    {
        if (!overlay || !skin || skin.burstFrames == null || skin.burstFrames.Length == 0) return;
        Vector2 position = overlay.InverseTransformPoint(piece.position);
        StartCoroutine(Burst(position));
    }

    Image Image(string name, Transform parent, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
        go.transform.SetParent(parent, false);
        var image = go.GetComponent<Image>();
        image.rectTransform.sizeDelta = size;
        image.preserveAspect = true;
        image.raycastTarget = false;
        return image;
    }

    IEnumerator Burst(Vector2 position)
    {
        var flash = Image("Lluentor", overlay, new Vector2(86, 86));
        flash.rectTransform.anchoredPosition = position;
        var sparks = new Image[6];
        for (int i = 0; i < sparks.Length; i++)
        {
            sparks[i] = Image("Espurna", flash.transform, new Vector2(14, 14));
            sparks[i].sprite = skin.burstFrames[0];
        }
        for (float elapsed = 0; elapsed < duration; elapsed += Time.unscaledDeltaTime)
        {
            float t = elapsed / duration;
            int frame = Mathf.Min(skin.burstFrames.Length - 1, (int)(t * skin.burstFrames.Length));
            flash.sprite = skin.burstFrames[frame];
            flash.color = new Color(1, 1, 1, 1 - t * t);
            for (int i = 0; i < sparks.Length; i++)
            {
                float angle = i * Mathf.PI * 2 / sparks.Length + .3f;
                sparks[i].rectTransform.anchoredPosition = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * Mathf.Lerp(8, 38, t);
                sparks[i].color = new Color(1, .94f, .7f, 1 - t);
                sparks[i].transform.localScale = Vector3.one * (1 - t * .7f);
            }
            yield return null;
        }
        Destroy(flash.gameObject);
    }

    public void Clear()
    {
        StopAllCoroutines();
        if (!overlay) return;
        foreach (Transform child in overlay)
        {
            child.gameObject.SetActive(false);
            Destroy(child.gameObject);
        }
    }

    void OnDisable() => Clear();
}
