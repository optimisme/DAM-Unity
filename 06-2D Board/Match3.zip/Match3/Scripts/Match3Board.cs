using System.Collections;
using TMPro;
using UnityEngine;

public sealed class Match3Board : MonoBehaviour
{
    public const float Step = 64f;
    [SerializeField] RectTransform area;
    [SerializeField] Match3Piece piecePrefab;
    [SerializeField] Match3Effects effects;
    [SerializeField] TMP_Text scoreText, movesText, messageText;
    [SerializeField, Min(1)] int target = 800;
    [SerializeField, Min(1)] int initialMoves = 20;
    [SerializeField] int seed = 12345;
    [SerializeField, Range(.05f, .5f)] float duration = .18f;
    Match3Model model;
    Match3Piece[,] pieces = new Match3Piece[Match3Model.Size, Match3Model.Size];
    int score, moves, selectedX = -1, selectedY = -1;
    bool busy, finished;
    public RectTransform Area => area;
    public bool CanInteract => !busy && !finished && model != null;
    public int Score => score;
    public int Moves => moves;
    public bool Finished => finished;
    public Match3Model Model => model;

    void Start()
    {
        if (!area || !piecePrefab || !scoreText || !movesText || !messageText)
        {
            Debug.LogError("Match3Board: arrossega totes les referències a l'Inspector.", this);
            enabled = false;
            return;
        }
        NewGame();
    }

    public Vector2 Position(int x, int y) => new Vector2((x - 3.5f) * Step, (y - 3.5f) * Step);

    public void NewGame()
    {
        if (!enabled) return;
        // També funciona durant una animació: cancel·lem les operacions de la partida anterior.
        StopAllCoroutines();
        if (effects) effects.Clear();
        busy = finished = false;
        selectedX = selectedY = -1;
        score = 0; moves = initialMoves;
        model = new Match3Model(seed); // Mateixa llavor = mateix repte inicial.
        Rebuild();
        RefreshHUD();
        messageText.text = "Clica dues veïnes o arrossega una peça.";
    }

    void Rebuild()
    {
        // Area només conté les peces creades pel joc. El prefab es desa fora de l'escena.
        foreach (Transform child in area)
        {
            child.gameObject.SetActive(false);
            Destroy(child.gameObject);
        }
        pieces = new Match3Piece[Match3Model.Size, Match3Model.Size];
        for (int y = 0; y < Match3Model.Size; y++)
            for (int x = 0; x < Match3Model.Size; x++)
                pieces[x, y] = CreatePiece(x, y, model.Cells[x, y], y);
    }

    Match3Piece CreatePiece(int x, int y, int type, int visualY)
    {
        var piece = Instantiate(piecePrefab, area);
        piece.name = $"Peça {x},{y}";
        piece.Setup(this, x, y, type);
        piece.Rect.anchoredPosition = Position(x, visualY);
        return piece;
    }

    public void Deselect()
    {
        if (selectedX >= 0 && pieces[selectedX, selectedY]) pieces[selectedX, selectedY].Select(false);
        selectedX = selectedY = -1;
    }

    public void Click(int x, int y)
    {
        if (!CanInteract || !model.Inside(x, y)) return;
        if (selectedX == x && selectedY == y) { Deselect(); return; }
        if (selectedX >= 0 && model.Adjacent(selectedX, selectedY, x, y))
        {
            TryMove(selectedX, selectedY, x, y);
            return;
        }
        Deselect();
        selectedX = x; selectedY = y;
        pieces[x, y].Select(true);
    }

    public void TryMove(int ax, int ay, int bx, int by)
    {
        if (!CanInteract || !model.Adjacent(ax, ay, bx, by)) return;
        Deselect();
        busy = true; // Bloquegem abans de començar la coroutine.
        StartCoroutine(Resolve(ax, ay, bx, by));
    }

    IEnumerator Slide(Match3Piece[] moving, Vector2[] targets)
    {
        var starts = new Vector2[moving.Length];
        for (int i = 0; i < moving.Length; i++) starts[i] = moving[i].Rect.anchoredPosition;
        for (float t = 0; t < duration; t += Time.unscaledDeltaTime)
        {
            float progress = Mathf.SmoothStep(0, 1, t / duration);
            for (int i = 0; i < moving.Length; i++)
                moving[i].Rect.anchoredPosition = Vector2.Lerp(starts[i], targets[i], progress);
            yield return null;
        }
        for (int i = 0; i < moving.Length; i++) moving[i].Rect.anchoredPosition = targets[i];
    }

    IEnumerator Resolve(int ax, int ay, int bx, int by)
    {
        bool valid = model.CanSwap(ax, ay, bx, by);
        var a = pieces[ax, ay]; var b = pieces[bx, by];
        yield return Slide(new[] { a, b }, new[] { Position(bx, by), Position(ax, ay) });
        if (!valid)
        {
            yield return Slide(new[] { a, b }, new[] { Position(ax, ay), Position(bx, by) });
            messageText.text = "Cal formar una línia de tres. No perds cap moviment.";
            busy = false;
            yield break;
        }
        model.Swap(ax, ay, bx, by);
        pieces[ax, ay] = b; pieces[bx, by] = a;
        b.SetCell(ax, ay); a.SetCell(bx, by);
        moves--; // Un intercanvi vàlid costa un moviment; les cascades no en gasten més.
        int wave = 0;
        var matches = model.FindMatches();
        while (matches.Count > 0)
        {
            wave++;
            score += matches.Count * 10;
            RefreshHUD();
            messageText.text = wave == 1 ? "Combinació!" : $"Cascada {wave}!";
            if (effects)
                foreach (int cell in matches)
                    effects.PlayAt(pieces[cell % 8, cell / 8].Rect);
            for (float t = 0; t < duration; t += Time.unscaledDeltaTime)
            {
                foreach (int cell in matches)
                    pieces[cell % 8, cell / 8].transform.localScale = Vector3.one * (1 - t / duration);
                yield return null;
            }
            foreach (int cell in matches)
            {
                int x = cell % 8, y = cell / 8;
                Destroy(pieces[x, y].gameObject);
                pieces[x, y] = null;
            }
            model.Clear(matches);
            var falls = model.CollapseAndRefill();
            var next = new Match3Piece[8, 8];
            var moving = new Match3Piece[falls.Count];
            var targets = new Vector2[falls.Count];
            for (int i = 0; i < falls.Count; i++)
            {
                var f = falls[i];
                var piece = f.IsNew ? CreatePiece(f.X, f.ToY, f.Type, f.FromY) : pieces[f.X, f.FromY];
                piece.SetCell(f.X, f.ToY);
                next[f.X, f.ToY] = moving[i] = piece;
                targets[i] = Position(f.X, f.ToY);
            }
            pieces = next;
            yield return Slide(moving, targets);
            matches = model.FindMatches();
            if (wave >= 100 && matches.Count > 0)
            {
                // Límit de seguretat: renovem les peces, conservant punts i moviments.
                model.Generate(); Rebuild();
                break;
            }
        }
        // Resolem totes les cascades abans de decidir si l'últim moviment guanya.
        finished = score >= target || moves == 0;
        if (score >= target) messageText.text = "Has guanyat! Prem Nova partida per repetir.";
        else if (moves == 0) messageText.text = "Sense moviments. Torna-ho a provar!";
        else if (!model.HasMove())
        {
            model.Generate(); Rebuild();
            messageText.text = "Sense jugades: tauler renovat. Conserves punts i moviments.";
        }
        else messageText.text = "Clica dues veïnes o arrossega una peça.";
        RefreshHUD();
        busy = false;
    }

    void RefreshHUD()
    {
        scoreText.text = $"Punts  {score} / {target}";
        movesText.text = $"Moviments  {moves}";
    }
}
