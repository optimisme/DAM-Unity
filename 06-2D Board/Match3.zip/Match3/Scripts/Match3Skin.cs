using UnityEngine;

[CreateAssetMenu(menuName = "Match3/Skin", fileName = "GemmesSkin")]
public sealed class Match3Skin : ScriptableObject
{
    public const int FramesPerGem = 4;
    [Tooltip("Cinc tipus, quatre fotogrames per tipus, en ordre de fila.")]
    public Sprite[] gemFrames = new Sprite[20];
    public Sprite[] burstFrames = new Sprite[4];
    [Range(1, 16)] public float framesPerSecond = 6f;

    public Sprite Gem(int type, int frame)
    {
        int index = type * FramesPerGem + frame;
        return gemFrames != null && index >= 0 && index < gemFrames.Length ? gemFrames[index] : null;
    }
}
