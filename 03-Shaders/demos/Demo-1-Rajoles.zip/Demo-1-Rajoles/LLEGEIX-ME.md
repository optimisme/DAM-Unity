# Demo-1-Rajoles

Projecte independent per a Unity 6000.6.3f1, URP i Shader Graph 17.6.0.

1. Obre aquesta carpeta amb Unity Hub (Add project from disk).
2. Espera la importació dels paquets.
3. Obre `Assets/Demos/Rajoles/Scenes/DemoRajoles.unity`.
4. Prem Play i clica Game. Els controls apareixen al panell.

Boto dret + arrossegar: orbita. Roda: zoom. Home: vista inicial. H amaga el panell. Els Shader Graphs són a Assets/Demos/Rajoles/Shaders.

El tutorial complet és Demo-1-Rajoles.md a la carpeta 03-Shaders del repositori DAM-Unity.
No cal cap recurs de tercers. La primera obertura pot necessitar Internet per resoldre els paquets.
