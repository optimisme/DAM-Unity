using System.Linq;
using UnityEditor;
using UnityEngine;
namespace DAMShaders.Catalog {
 public class MaterialWorkshop:EditorWindow {
  [SerializeField] Material material;MaterialEditor inspector;Vector2 scroll;[SerializeField] int selected=5;
  [MenuItem("DAM/Materials: taller individual")]
  public static void Open(){GetWindow<MaterialWorkshop>("Taller de materials").Show();}
  void OnEnable(){if(material)Pick(material);}
  void OnDisable(){if(inspector)DestroyImmediate(inspector);}
  void Pick(Material m){material=m;if(inspector)DestroyImmediate(inspector);inspector=m?Editor.CreateEditor(m,typeof(MaterialEditor)) as MaterialEditor:null;}
  void OnGUI(){if(material&&!inspector)Pick(material);
   var nav=Object.FindFirstObjectByType<CatalogNavigator>();
   if(!nav){EditorGUILayout.HelpBox("Obre CatalegMaterials per utilitzar el taller.",MessageType.Info);return;}
   EditorGUILayout.HelpBox("Ailla una familia o combina caselles. Edita sense Play; utilitza Play per veure les animacions. Els canvis del material es desen a l'asset.",MessageType.Info);
   var roots=CatalogIsolation.Groups(nav);var visible=new bool[15];foreach(var go in roots){int i=CatalogIsolation.FamilyOf(go);if(i>=0&&go.activeSelf)visible[i]=true;}
   if(visible.Count(v=>v)==1){int active=System.Array.FindIndex(visible,v=>v);if(active!=selected){selected=active;Pick(AssetDatabase.LoadAssetAtPath<Material>("Assets/DAMShaders/Library/Materials/M_"+(active==14?"GalaxySuperficie":CatalogIsolation.Families[active])+".mat"));}}
   for(int row=0;row<5;row++){EditorGUILayout.BeginHorizontal();for(int col=0;col<3;col++){int i=row*3+col;bool next=GUILayout.Toggle(visible[i],GUIContent.none,GUILayout.Width(18));if(next!=visible[i]){visible[i]=next;Apply(nav,roots,visible);}if(GUILayout.Button(CatalogIsolation.Families[i])){selected=i;var flags=new bool[15];flags[i]=true;Apply(nav,roots,flags);if(Application.isPlaying)nav.cameraControl.Focus(nav.centers[i]);else if(SceneView.lastActiveSceneView)SceneView.lastActiveSceneView.LookAt(nav.centers[i],Quaternion.Euler(25,-35,0),7);Pick(AssetDatabase.LoadAssetAtPath<Material>("Assets/DAMShaders/Library/Materials/M_"+(i==14?"GalaxySuperficie":CatalogIsolation.Families[i])+".mat"));}}EditorGUILayout.EndHorizontal();}
   if(GUILayout.Button("Mostrar totes les families")){var all=Enumerable.Repeat(true,15).ToArray();Apply(nav,roots,all);}
   string prefix="M_"+(selected==14?"Galaxy":CatalogIsolation.Families[selected]);
   var choices=AssetDatabase.FindAssets("t:Material",new[]{"Assets/DAMShaders/Library/Materials"}).Select(AssetDatabase.GUIDToAssetPath).Where(p=>p.EndsWith(".mat")).Select(AssetDatabase.LoadAssetAtPath<Material>).Where(m=>m.name.StartsWith(prefix)).OrderBy(m=>m.name).ToArray();
   for(int j=0;j<choices.Length;j+=2){EditorGUILayout.BeginHorizontal();for(int k=j;k<Mathf.Min(j+2,choices.Length);k++)if(GUILayout.Button(choices[k].name))Pick(choices[k]);EditorGUILayout.EndHorizontal();}
   if(material&&GUILayout.Button("Aplicar aquest material als exemples")){if(nav.groups!=null&&nav.groups.Length>selected&&nav.groups[selected])foreach(var renderer in nav.groups[selected].examples){if(!renderer)continue;if(selected==14&&renderer.gameObject.name!=(material.name.Contains("Fons")?"Fons":"Superficie"))continue;Undo.RecordObject(renderer,"Canviar material de prova");renderer.sharedMaterial=material;EditorUtility.SetDirty(renderer);}SceneView.RepaintAll();}
   var changed=(Material)EditorGUILayout.ObjectField("Material",material,typeof(Material),false);if(changed!=material)Pick(changed);
   if(inspector){scroll=EditorGUILayout.BeginScrollView(scroll);foreach(var property in MaterialEditor.GetMaterialProperties(new Object[]{material})) if((property.propertyFlags & UnityEngine.Rendering.ShaderPropertyFlags.HideInInspector)==0) inspector.ShaderProperty(property,property.displayName);EditorGUILayout.EndScrollView();}
  }
  static void Apply(CatalogNavigator nav,GameObject[] roots,bool[] flags){if(!Application.isPlaying)Undo.RecordObjects(roots,"Aillar materials");CatalogIsolation.Apply(nav,flags);SceneView.RepaintAll();}
 }
}
