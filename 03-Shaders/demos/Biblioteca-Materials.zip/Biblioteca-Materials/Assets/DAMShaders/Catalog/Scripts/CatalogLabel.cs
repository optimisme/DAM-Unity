using UnityEngine;
namespace DAMShaders.Catalog {
public class CatalogLabel : MonoBehaviour {
 void LateUpdate(){if(Camera.main)transform.rotation=Quaternion.LookRotation(Camera.main.transform.forward,Vector3.up);}
}}
