using UnityEngine;
using UnityEngine.InputSystem;
namespace DAMShaders.Catalog {
public class CatalogNavigator : MonoBehaviour {
 public CatalogCamera cameraControl;
 public CatalogGroup[] groups;
 public string[] names;
 public Vector3[] centers;
 bool panel=true;
 void Start(){CatalogIsolation.Solo(this,0);cameraControl.Focus(centers[0]);cameraControl.IsPointerOverControls=p=>panel&&new Rect(16,16,250,610).Contains(p);}
 void Update(){if(Keyboard.current!=null&&Keyboard.current.homeKey.wasPressedThisFrame)CatalogIsolation.All(this);if(Keyboard.current!=null&&Keyboard.current.hKey.wasPressedThisFrame)panel=!panel;}
 void OnGUI(){if(!panel)return;GUI.Box(new Rect(16,16,250,610),"");GUILayout.BeginArea(new Rect(28,27,226,590));GUILayout.Label("DAM / MATERIALS DE JOC");GUILayout.Label("Tria un material per aillar-lo");for(int i=0;i<names.Length;i++)if(GUILayout.Button(names[i],GUILayout.Height(27))){CatalogIsolation.Solo(this,i);cameraControl.Focus(centers[i]);}if(GUILayout.Button("Vista general / Home")){CatalogIsolation.All(this);cameraControl.ResetView();}GUILayout.Label("Boto dret: orbita  |  Roda: zoom");GUILayout.Label("H: amaga aquest panell");GUILayout.EndArea();}
}}
