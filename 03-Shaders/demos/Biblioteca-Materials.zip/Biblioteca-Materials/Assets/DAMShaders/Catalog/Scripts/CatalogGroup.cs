using UnityEngine;
namespace DAMShaders.Catalog {
 // Un grup de la Hierarchy agrupa geometria, pedestal i etiqueta.
 public class CatalogGroup:MonoBehaviour {
  [HideInInspector] public int familyIndex;
  public Renderer[] examples;
 }
}
