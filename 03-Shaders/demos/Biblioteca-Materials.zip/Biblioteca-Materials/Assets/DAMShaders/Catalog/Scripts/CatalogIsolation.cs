using System;
using UnityEngine;
namespace DAMShaders.Catalog {
 public static class CatalogIsolation {
  public static readonly string[] Families={"Base","Patrons","Maons","Herba","Roca","Metall","Neu","Gel","Aigua","Emissiu","Energia","Lava","Fusta","Plastic","Galaxy"};
  public static int FamilyOf(GameObject go){
   var group=go.GetComponent<CatalogGroup>();if(group)return group.familyIndex;
   for(int i=0;i<14;i++)if(go.name.StartsWith(Families[i]+"_",StringComparison.Ordinal)||go.name=="Pedestal_"+Families[i]||go.name==i.ToString("00")+" / "+Families[i].ToUpperInvariant())return i;
   return go.name=="AiguaGalaxy"||go.name=="AIGUA GALAXY"?14:-1;
  }
  public static GameObject[] Groups(CatalogNavigator nav){if(nav.groups!=null&&nav.groups.Length==15&&Array.TrueForAll(nav.groups,g=>g!=null))return Array.ConvertAll(nav.groups,g=>g.gameObject);return nav.gameObject.scene.GetRootGameObjects();}
  public static void Apply(CatalogNavigator nav,bool[] visible){foreach(var go in Groups(nav)){int i=FamilyOf(go);if(i>=0)go.SetActive(visible[i]);}}
  public static void Solo(CatalogNavigator nav,int index){var flags=new bool[15];flags[index]=true;Apply(nav,flags);}
  public static void All(CatalogNavigator nav){var flags=new bool[15];Array.Fill(flags,true);Apply(nav,flags);}
 }
}
