# Biblioteca de materials DAM

14 famílies de materials de colors vius, incloses fusta i plàstic: 16 Shader Graphs i 36 materials.

Obre el projecte amb Unity 6000.6.3f1. Utilitza URP / Shader Graph 17.6.0 i Input System 1.20.0.

Obre Assets/DAMShaders/Catalog/Scenes/CatalegMaterials.unity i prem Play.

- Botons: selecciona una família.
- Botó dret + arrossegar: orbita.
- Roda: zoom.
- Home: vista general.
- H: mostra/amaga el panell.

Per reutilitzar només els materials, importa DAM-Shaders.unitypackage en un projecte URP amb Assets > Import Package > Custom Package. També pots copiar tota la carpeta Assets/DAMShaders/Library conservant els .meta. Duplica els materials per personalitzar-los.

La biblioteca no necessita scripts ni Input System. L’escuma de contacte de l’aigua necessita Depth Texture. El prefab AiguaGalaxy té la superfície a Y=0.8; ajusta NivellAigua del material del fons si el mous verticalment. Les animacions utilitzen Time de Shader Graph.

Les textures s’han creat per a aquesta biblioteca. No conté recursos extrets de jocs comercials. La guia completa és Biblioteca-Materials.md, a 03-Shaders del repositori DAM-Unity.

Per treballar amb menys càrrega: DAM > Materials: taller individual. Un botó aïlla la família; les caselles permeten combinar-les. El taller edita els paràmetres del material sense Play. Play només és necessari per observar les animacions.

Inclou gel amb profunditat aparent i variants de fusta, roca i maons. Al taller, tria M_… i prem Aplicar aquest material als exemples.

Textures: 84 PNG, incloent 22 mapes Altura i tres variants -V1/-V2/-V3 de cada tipus. El gel té MapaAltura i Parallax Mapping. Profunditat 0.28 dona un efecte marcat; 0 el desactiva. Els mapes auxiliars de les altres famílies es proporcionen per ampliar els grafs.

Hierarchy: Exemples conté un objecte buit per família (00-Base fins a 14-AiguaGalaxy). Activa o desactiva cada grup des de la casella de l’Inspector.
