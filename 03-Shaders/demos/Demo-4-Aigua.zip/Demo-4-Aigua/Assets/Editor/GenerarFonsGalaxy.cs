using UnityEngine;
using UnityEditor;
using System.IO;

public static class GenerarFonsGalaxy
{
    [MenuItem("Demos/Crear fons inclinat Galaxy")]
    public static void Crear()
    {
        // Quatre vertexs son suficients: aquest shader no deforma la geometria.
        var mesh = new Mesh { name = "FonsInclinat" };
        mesh.vertices = new[] {
            new Vector3(-4, .45f, -2.5f), new Vector3(4, -.7f, -2.5f),
            new Vector3(-4, .45f, 2.5f), new Vector3(4, -.7f, 2.5f)
        };
        mesh.uv = new[] { Vector2.zero, Vector2.right, Vector2.up, Vector2.one };
        mesh.triangles = new[] { 0, 2, 1, 1, 2, 3 };
        mesh.RecalculateNormals(); mesh.RecalculateTangents(); mesh.RecalculateBounds();
        Directory.CreateDirectory("Assets/Meshes");
        AssetDatabase.CreateAsset(mesh, AssetDatabase.GenerateUniqueAssetPath("Assets/Meshes/FonsInclinat.asset"));
        AssetDatabase.SaveAssets();
        Selection.activeObject = mesh;
    }
}
