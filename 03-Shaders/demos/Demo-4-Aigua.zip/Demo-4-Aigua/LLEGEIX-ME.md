# Demo-4-Aigua

Projecte independent per a Unity 6000.6.3f1, URP i Shader Graph 17.6.0.

1. Obre aquesta carpeta amb Unity Hub (Add project from disk).
2. Espera la importació dels paquets.
3. Obre `Assets/Demos/Aigua/Scenes/DemoAigua.unity`.
4. Prem Play i clica Game. Els controls apareixen al panell.

Boto dret + arrossegar: orbita. Roda: zoom. Home: vista inicial. H amaga el panell. Els Shader Graphs són a Assets/Demos/Aigua/Shaders.

El tutorial complet és Demo-4-Aigua.md a la carpeta 03-Shaders del repositori DAM-Unity.
No cal cap recurs de tercers. La primera obertura pot necessitar Internet per resoldre els paquets.

Aquest projecte inclou també DemoAiguaGalaxy.unity: superfície plana, textures, càustiques i escuma de contacte. Obre aquesta escena per comparar les dues aproximacions.
