using UnityEngine;

public class CoinPickup : MonoBehaviour
{
    public Transform visual;
    public float rotationSpeed = 90f;

    private bool collected;

    void Update()
    {
        if (visual != null)
            visual.Rotate(Vector3.up, rotationSpeed * Time.deltaTime, Space.World);
    }

    void OnTriggerEnter(Collider other)
    {
        CoinCollector collector = other.GetComponent<CoinCollector>();

        // Only the player with an active collector can pick up a coin.
        if (collected || collector == null || !collector.isActiveAndEnabled)
            return;

        collected = true;
        collector.CollectCoin();
        gameObject.SetActive(false);
    }
}
