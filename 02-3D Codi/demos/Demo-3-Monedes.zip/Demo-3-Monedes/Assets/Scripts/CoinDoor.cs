using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class CoinDoor : MonoBehaviour
{
    public float openHeight = 3.5f;
    public float speed = 2f;

    private Rigidbody body;
    private Vector3 openPosition;
    private bool opening;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        openPosition = body.position + Vector3.up * openHeight;
    }

    public void Open()
    {
        opening = true;
    }

    void FixedUpdate()
    {
        if (!opening)
            return;

        Vector3 nextPosition = Vector3.MoveTowards(
            body.position, openPosition, speed * Time.fixedDeltaTime
        );

        body.MovePosition(nextPosition);
    }
}
