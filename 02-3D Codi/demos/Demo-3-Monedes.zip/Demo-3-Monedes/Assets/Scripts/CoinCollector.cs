using TMPro;
using UnityEngine;

public class CoinCollector : MonoBehaviour
{
    public Transform coinsRoot;
    public TMP_Text counterText;
    public CoinDoor door;

    private int totalCoins;
    private int collectedCoins;

    void Start()
    {
        if (coinsRoot == null || counterText == null || door == null)
        {
            Debug.LogError("Assigna Coins Root, Counter Text i Door al Player.", this);
            enabled = false;
            return;
        }

        // Count the active coins in this level once, before collecting any.
        totalCoins = coinsRoot.GetComponentsInChildren<CoinPickup>().Length;

        if (totalCoins == 0)
        {
            Debug.LogError("Afegeix almenys una moneda activa dins de Coins.", this);
            enabled = false;
            return;
        }

        RefreshCounter();
    }

    public void CollectCoin()
    {
        collectedCoins++;
        RefreshCounter();

        if (collectedCoins == totalCoins)
            door.Open();
    }

    void RefreshCounter()
    {
        counterText.text = $"Monedes: {collectedCoins}/{totalCoins}";

        if (collectedCoins == totalCoins)
            counterText.text += "\nPorta oberta!";
    }
}
