# Demo-7-Duel

Projecte independent: Unity 6.6 (6000.6.3f1), URP i Input System.

1. Descomprimeix tot el ZIP.
2. A Unity Hub, afegeix la carpeta Demo-7-Duel, amb Assets, Packages i ProjectSettings.
3. Obre-la amb Unity 6000.6.3f1 i espera la importació i instal·lació dels paquets.
4. Obre Assets/Scenes/DemoDuel.unity i prem Play. Clica Game.
5. WASD o fletxes: moure. Ratolí: apuntar. Botó esquerre: disparar. R: reiniciar.
6. Esquiva les bales lentes i utilitza els murs per cobrir-te. Guanya qui deixa el rival sense vida.

Cada càpsula té tres vides. L'enemic avisa en groc abans de disparar.
Les bales avancen a 4.5 unitats/s. Prem R per tornar a començar.

Tutorial: Demo-7-Duel.md als apunts. Les captures són externes al ZIP.
No inclou Library, Temp ni Logs. Unity regenerarà la memòria cau.
La primera obertura requereix Internet per instal·lar els paquets i més espai en disc.
