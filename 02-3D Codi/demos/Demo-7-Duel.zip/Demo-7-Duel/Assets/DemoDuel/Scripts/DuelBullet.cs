using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
public class DuelBullet : MonoBehaviour
{
    public float lifetime = 4;
    DuelFighter owner;
    bool spent;
    Material material;

    public void Launch(DuelFighter shooter, Vector3 direction, float speed, Color color)
    {
        owner = shooter;
        var bulletCollider = GetComponent<Collider>();
        foreach (var ownCollider in shooter.GetComponentsInChildren<Collider>())
            Physics.IgnoreCollision(bulletCollider, ownCollider);
        material = GetComponent<Renderer>().material;
        material.SetColor("_BaseColor", color);
        GetComponent<Rigidbody>().linearVelocity = direction * speed;
        Destroy(gameObject, lifetime);
    }

    void OnCollisionEnter(Collision collision)
    {
        if (spent) return;
        var fighter = collision.collider.GetComponentInParent<DuelFighter>();
        if (fighter == owner) return;
        spent = true;
        if (fighter != null) fighter.TakeHit();
        Remove();
    }

    public void Remove()
    {
        spent = true;
        gameObject.SetActive(false);
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        if (material != null) Destroy(material);
    }
}
