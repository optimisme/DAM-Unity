using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController), typeof(DuelFighter))]
public class DuelPlayer : MonoBehaviour
{
    public Camera aimCamera;
    public float speed = 3.5f;
    CharacterController controller;
    DuelFighter fighter;
    float verticalSpeed;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        fighter = GetComponent<DuelFighter>();
    }

    void Update()
    {
        if (fighter.game.IsOver) return;
        Vector2 input = Vector2.zero;
        var keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y++;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y--;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x--;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x++;
        }
        input = Vector2.ClampMagnitude(input, 1);
        if (controller.isGrounded && verticalSpeed < 0) verticalSpeed = -2;
        verticalSpeed -= 20 * Time.deltaTime;
        controller.Move(new Vector3(input.x * speed, verticalSpeed, input.y * speed) * Time.deltaTime);

        var mouse = Mouse.current;
        if (mouse == null) return;
        Vector2 screen = mouse.position.ReadValue();
        // Només apunta i dispara quan el punter és dins la vista de joc.
        if (!aimCamera.pixelRect.Contains(screen)) return;
        Ray ray = aimCamera.ScreenPointToRay(screen);
        Plane aimPlane = new Plane(Vector3.up, new Vector3(0, transform.position.y, 0));
        if (!aimPlane.Raycast(ray, out float distance)) return;
        Vector3 direction = ray.GetPoint(distance) - transform.position;
        direction.y = 0;
        if (direction.sqrMagnitude < 0.01f) return;
        transform.rotation = Quaternion.LookRotation(direction);
        if (mouse.leftButton.isPressed) fighter.Fire(direction);
    }

    public void ResetMotion() => verticalSpeed = 0;
}
