using UnityEngine;

[RequireComponent(typeof(CharacterController), typeof(DuelFighter))]
public class DuelEnemy : MonoBehaviour
{
    public enum EnemyState { Patrol, Warning, Recovery }
    public Transform player;
    public Transform[] points;
    public Renderer body;
    public float speed = 1.5f;
    public float sightDistance = 14;
    public float warningTime = 0.8f;
    public float recoveryTime = 1.1f;
    public EnemyState State { get; private set; }
    CharacterController controller;
    DuelFighter fighter;
    Material material;
    int nextPoint;
    float timer;
    Vector3 shotDirection;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        fighter = GetComponent<DuelFighter>();
        material = body.material;
    }

    public void ResetBrain()
    {
        nextPoint = 1 % points.Length;
        timer = 0;
        SetState(EnemyState.Patrol);
    }

    public bool CanSeePlayer()
    {
        return Vector3.Distance(transform.position, player.position) <= sightDistance &&
            !Physics.Linecast(transform.position, player.position, fighter.wallsMask, QueryTriggerInteraction.Ignore);
    }

    void Update()
    {
        if (fighter.game.IsOver) return;
        if (State == EnemyState.Patrol)
        {
            if (CanSeePlayer())
            {
                shotDirection = player.position - transform.position;
                shotDirection.y = 0;
                if (shotDirection.sqrMagnitude < 0.001f) return;
                transform.rotation = Quaternion.LookRotation(shotDirection);
                timer = warningTime;
                SetState(EnemyState.Warning);
            }
            else
            {
                Vector3 delta = points[nextPoint].position - transform.position;
                delta.y = 0;
                if (delta.magnitude < 0.06f) nextPoint = (nextPoint + 1) % points.Length;
                else
                {
                    transform.rotation = Quaternion.LookRotation(delta);
                    Vector3 movement = Vector3.ClampMagnitude(delta, speed * Time.deltaTime);
                    movement.y = -2 * Time.deltaTime;
                    controller.Move(movement);
                }
            }
        }
        else
        {
            timer -= Time.deltaTime;
            if (timer > 0) return;
            if (State == EnemyState.Warning)
            {
                // Manté la direcció anunciada: el jugador pot esquivar el tret.
                fighter.Fire(shotDirection);
                timer = recoveryTime;
                SetState(EnemyState.Recovery);
            }
            else SetState(EnemyState.Patrol);
        }
    }

    void SetState(EnemyState state)
    {
        State = state;
        material.SetColor("_BaseColor", state == EnemyState.Warning ?
            new Color(1, 0.8f, 0.1f) : new Color(0.9f, 0.2f, 0.15f));
    }

    void OnDestroy()
    {
        if (material != null) Destroy(material);
    }
}
