using UnityEngine;

public class DuelFighter : MonoBehaviour
{
    public DuelGame game;
    public DuelBullet bulletPrefab;
    public LayerMask wallsMask;
    public Color bulletColor = Color.cyan;
    public int maxLife = 3;
    public float bulletSpeed = 4.5f;
    public float shotInterval = 0.5f;
    public float muzzleOffset = 0.9f;
    public float bulletRadius = 0.15f;
    public int Life { get; private set; }
    float nextShot;

    public void ResetFighter()
    {
        Life = maxLife;
        nextShot = 0;
    }

    public bool Fire(Vector3 direction)
    {
        if (game.IsOver || Life <= 0 || Time.time < nextShot) return false;
        direction.y = 0;
        if (direction.sqrMagnitude < 0.001f) return false;
        direction.Normalize();
        nextShot = Time.time + shotInterval;
        // Evita crear la bala a l'altra banda d'un mur molt proper.
        if (Physics.SphereCast(transform.position, bulletRadius, direction,
            out _, muzzleOffset, wallsMask, QueryTriggerInteraction.Ignore)) return false;
        DuelBullet bullet = Instantiate(bulletPrefab,
            transform.position + direction * muzzleOffset, Quaternion.LookRotation(direction));
        bullet.Launch(this, direction, bulletSpeed, bulletColor);
        return true;
    }

    public void TakeHit()
    {
        if (game.IsOver || Life <= 0) return;
        Life--;
        if (Life == 0) game.Finish(this);
    }
}
