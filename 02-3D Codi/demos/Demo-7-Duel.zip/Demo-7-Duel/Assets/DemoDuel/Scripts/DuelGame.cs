using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class DuelGame : MonoBehaviour
{
    public DuelFighter player;
    public DuelFighter enemy;
    public TMP_Text status;
    public bool IsOver { get; private set; }
    Vector3 playerStart, enemyStart;
    Quaternion playerRotation, enemyRotation;
    string result;

    void Start()
    {
        playerStart = player.transform.position;
        enemyStart = enemy.transform.position;
        playerRotation = player.transform.rotation;
        enemyRotation = enemy.transform.rotation;
        ResetRound();
    }

    void Update()
    {
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame) ResetRound();
        string state = enemy.GetComponent<DuelEnemy>().State == DuelEnemy.EnemyState.Warning ?
            "Atenció: està preparant un tret!" : "Utilitza els murs per cobrir-te.";
        status.text = "Vida: " + player.Life + " / " + player.maxLife +
            "     Contrincant: " + enemy.Life + " / " + enemy.maxLife + "\n" +
            (IsOver ? result + " Prem R per reiniciar." : state);
    }

    public void Finish(DuelFighter defeated)
    {
        if (IsOver) return;
        IsOver = true;
        result = defeated == enemy ? "Has guanyat!" : "Has perdut!";
        ClearBullets();
    }

    public void ResetRound()
    {
        ClearBullets();
        IsOver = false;
        ResetActor(player, playerStart, playerRotation);
        ResetActor(enemy, enemyStart, enemyRotation);
        player.GetComponent<DuelPlayer>().ResetMotion();
        enemy.GetComponent<DuelEnemy>().ResetBrain();
        Physics.SyncTransforms();
    }

    void ResetActor(DuelFighter actor, Vector3 position, Quaternion rotation)
    {
        var controller = actor.GetComponent<CharacterController>();
        controller.enabled = false;
        actor.transform.SetPositionAndRotation(position, rotation);
        controller.enabled = true;
        actor.ResetFighter();
    }

    void ClearBullets()
    {
        foreach (var bullet in FindObjectsByType<DuelBullet>(FindObjectsSortMode.None)) bullet.Remove();
    }
}
