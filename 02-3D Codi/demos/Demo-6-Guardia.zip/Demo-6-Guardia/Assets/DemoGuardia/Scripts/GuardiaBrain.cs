using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class GuardiaBrain : MonoBehaviour
{
    public enum GuardState { Patrol, Chase, Return }
    public GuardiaPlayer player;
    public GuardiaGame game;
    public Transform[] points;
    public Renderer body;
    public LayerMask wallsMask;
    public float patrolSpeed = 1.4f;
    public float chaseSpeed = 2.2f;
    public float viewDistance = 5;
    public float viewAngle = 100;
    public float memoryTime = 2;
    public float catchDistance = 1.05f;
    public GuardState State { get; private set; }
    public bool SeesPlayer { get; private set; }

    CharacterController controller;
    Material material;
    int nextPoint;
    float lostTime;
    Vector3 lastSeen;
    readonly List<Vector3> trail = new List<Vector3>();

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        material = body.material;
    }

    void OnDestroy()
    {
        if (material != null) Destroy(material);
    }

    public void ResetGuard()
    {
        controller.enabled = false;
        transform.position = points[0].position;
        controller.enabled = true;
        nextPoint = 1 % points.Length;
        Face(points[nextPoint].position - transform.position, true);
        lostTime = 0;
        SeesPlayer = false;
        trail.Clear();
        SetState(GuardState.Patrol);
    }

    public bool CanSeePlayer()
    {
        Vector3 delta = player.transform.position - transform.position;
        delta.y = 0;
        if (delta.magnitude > viewDistance) return false;
        if (delta.sqrMagnitude > 0.001f && Vector3.Angle(transform.forward, delta) > viewAngle * 0.5f)
            return false;
        Vector3 eye = transform.position + Vector3.up * 0.3f;
        Vector3 target = player.transform.position + Vector3.up * 0.3f;
        return !Physics.Linecast(eye, target, wallsMask, QueryTriggerInteraction.Ignore);
    }

    void Update()
    {
        if (game.Won) return;
        SeesPlayer = CanSeePlayer();
        if (SeesPlayer)
        {
            if (State == GuardState.Patrol)
            {
                trail.Clear();
                trail.Add(transform.position);
            }
            // Si el veu mentre torna, conserva el camí per poder desfer-lo després.
            SetState(GuardState.Chase);
            lostTime = 0;
            lastSeen = player.transform.position;
            lastSeen.y = transform.position.y;
        }
        else if (State == GuardState.Chase)
        {
            lostTime += Time.deltaTime;
            if (lostTime >= memoryTime) SetState(GuardState.Return);
        }

        if (State == GuardState.Patrol)
        {
            if (WalkTo(points[nextPoint].position, patrolSpeed))
                nextPoint = (nextPoint + 1) % points.Length;
        }
        else if (State == GuardState.Chase)
        {
            WalkTo(lastSeen, chaseSpeed);
            if (trail.Count == 0 || FlatDistance(transform.position, trail[trail.Count - 1]) >= 0.3f)
                trail.Add(transform.position);
            Vector3 eye = transform.position + Vector3.up * 0.3f;
            Vector3 target = player.transform.position + Vector3.up * 0.3f;
            if (FlatDistance(transform.position, player.transform.position) < catchDistance &&
                !Physics.Linecast(eye, target, wallsMask, QueryTriggerInteraction.Ignore))
                game.ResetRound(true);
        }
        else
        {
            // Recorre en ordre invers les posicions per on realment ha passat.
            if (trail.Count == 0) SetState(GuardState.Patrol);
            else if (WalkTo(trail[trail.Count - 1], patrolSpeed)) trail.RemoveAt(trail.Count - 1);
        }
    }

    bool WalkTo(Vector3 target, float speed)
    {
        Vector3 delta = target - transform.position;
        delta.y = 0;
        if (delta.magnitude < 0.06f) return true;
        Face(delta, false);
        Vector3 movement = Vector3.ClampMagnitude(delta, speed * Time.deltaTime);
        movement.y = -2 * Time.deltaTime;
        controller.Move(movement);
        return false;
    }

    void Face(Vector3 direction, bool instant)
    {
        direction.y = 0;
        if (direction.sqrMagnitude < 0.001f) return;
        Quaternion target = Quaternion.LookRotation(direction);
        transform.rotation = instant ? target : Quaternion.RotateTowards(transform.rotation, target, 540 * Time.deltaTime);
    }

    void SetState(GuardState state)
    {
        State = state;
        Color color = state == GuardState.Patrol ? new Color(0.15f, 0.55f, 1) :
                      state == GuardState.Chase ? new Color(1, 0.15f, 0.1f) : new Color(1, 0.8f, 0.1f);
        material.SetColor("_BaseColor", color);
    }

    static float FlatDistance(Vector3 a, Vector3 b)
    {
        a.y = b.y = 0;
        return Vector3.Distance(a, b);
    }
}
