using UnityEngine;
using UnityEngine.Rendering;

[RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
public class GuardiaVision : MonoBehaviour
{
    public GuardiaBrain guard;
    [Range(8, 120)] public int segments = 40;
    public float groundHeight = 0.07f;
    Mesh mesh;
    Material material;
    Vector3[] vertices;
    int[] triangles;

    void Awake()
    {
        mesh = new Mesh { name = "Camp de visió" };
        GetComponent<MeshFilter>().mesh = mesh;
        var renderer = GetComponent<MeshRenderer>();
        renderer.shadowCastingMode = ShadowCastingMode.Off;
        renderer.receiveShadows = false;
        material = renderer.material;
        vertices = new Vector3[segments + 2];
        triangles = new int[segments * 3];
        for (int i = 0; i < segments; i++)
        {
            triangles[i * 3] = 0;
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = i + 2;
        }
    }

    void LateUpdate()
    {
        Vector3 eye = guard.transform.position + Vector3.up * 0.3f;
        Vector3 center = guard.transform.position;
        center.y = groundHeight;
        vertices[0] = transform.InverseTransformPoint(center);
        for (int i = 0; i <= segments; i++)
        {
            float angle = Mathf.Lerp(-guard.viewAngle * 0.5f, guard.viewAngle * 0.5f, (float)i / segments);
            Vector3 direction = Quaternion.AngleAxis(angle, Vector3.up) * guard.transform.forward;
            float distance = guard.viewDistance;
            if (Physics.Raycast(eye, direction, out RaycastHit hit, distance, guard.wallsMask, QueryTriggerInteraction.Ignore))
                distance = hit.distance;
            vertices[i + 1] = transform.InverseTransformPoint(center + direction * distance);
        }
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.RecalculateBounds();
        Color color = guard.State == GuardiaBrain.GuardState.Patrol ? new Color(0.15f, 0.55f, 1, 0.18f) :
                      guard.State == GuardiaBrain.GuardState.Chase ? new Color(1, 0.15f, 0.1f, 0.18f) :
                      new Color(1, 0.8f, 0.1f, 0.18f);
        material.SetColor("_BaseColor", color);
    }

    void OnDestroy()
    {
        if (mesh != null) Destroy(mesh);
        if (material != null) Destroy(material);
    }
}
