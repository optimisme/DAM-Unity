# Demo-6-Guardia

Projecte independent: Unity 6.6 (6000.6.3f1), URP i Input System.

1. Descomprimeix tot el ZIP.
2. A Unity Hub, afegeix la carpeta Demo-6-Guardia, amb Assets, Packages i ProjectSettings.
3. Obre-la amb Unity 6000.6.3f1 i espera la importació i instal·lació dels paquets.
4. Obre Assets/Scenes/DemoGuardia.unity i prem Play. Clica Game.
5. WASD o fletxes: moure la càpsula. R: reiniciar.
6. Recull la clau, evita el vigilant i entra a la sortida verda quan s'obri la porta.

El vigilant patrulla en blau, persegueix en vermell i torna al camí en groc.
Si t'atrapa, la partida torna a començar. Després de guanyar, prem R.

Tutorial: Demo-6-Guardia.md als apunts. Les captures són externes al ZIP.
No inclou Library, Temp ni Logs. Unity regenerarà la memòria cau.
La primera obertura requereix Internet per instal·lar els paquets i més espai en disc.
