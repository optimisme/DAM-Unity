using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class SaltGame : MonoBehaviour
{
    public SaltPlayer player;
    public Transform startPoint;
    public SaltCheckpoint checkpoint;
    public TMP_Text status;
    public bool Won { get; private set; }
    public bool HasCheckpoint { get; private set; }
    public int Falls { get; private set; }
    Vector3 respawnPosition;

    void Start() => Restart();

    void Update()
    {
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame) Restart();
        status.text = Won ? "Has arribat! Prem R per tornar a començar." :
            "Caigudes: " + Falls + "     Checkpoint: " + (HasCheckpoint ? "activat" : "pendent");
    }

    public void ActivateCheckpoint(SaltCheckpoint point)
    {
        if (Won || HasCheckpoint) return;
        HasCheckpoint = true;
        respawnPosition = point.spawnPoint.position;
        point.SetActiveColor(true);
    }

    public void Fall()
    {
        if (Won) return;
        Falls++;
        player.Teleport(respawnPosition);
    }

    public void Finish() => Won = true;

    public void Restart()
    {
        Won = false;
        HasCheckpoint = false;
        Falls = 0;
        respawnPosition = startPoint.position;
        checkpoint.SetActiveColor(false);
        player.Teleport(respawnPosition);
    }
}
