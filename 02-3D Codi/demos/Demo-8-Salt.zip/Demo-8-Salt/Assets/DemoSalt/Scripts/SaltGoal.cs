using UnityEngine;

public class SaltGoal : MonoBehaviour
{
    public SaltGame game;

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<SaltPlayer>() == game.player) game.Finish();
    }
}
