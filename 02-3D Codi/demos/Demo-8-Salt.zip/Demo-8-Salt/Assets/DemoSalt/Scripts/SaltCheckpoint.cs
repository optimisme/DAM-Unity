using UnityEngine;

public class SaltCheckpoint : MonoBehaviour
{
    public SaltGame game;
    public Transform spawnPoint;
    public Renderer visual;
    Material material;

    void Awake() => material = visual.material;

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<SaltPlayer>() == game.player && !game.Won)
            game.ActivateCheckpoint(this);
    }

    public void SetActiveColor(bool active)
    {
        material.SetColor("_BaseColor", active ? new Color(0.2f, 0.9f, 0.4f) : new Color(0.2f, 0.6f, 1));
    }

    void OnDestroy()
    {
        if (material != null) Destroy(material);
    }
}
