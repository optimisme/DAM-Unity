using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public class SaltPlayer : MonoBehaviour
{
    public SaltGame game;
    public float speed = 4;
    public float jumpSpeed = 8;
    public float gravity = 20;
    public float releaseGravity = 35;
    public float coyoteTime = 0.12f;
    public float jumpBuffer = 0.12f;
    CharacterController controller;
    float verticalSpeed;
    float lastGrounded = float.NegativeInfinity;
    float lastJumpPressed = float.NegativeInfinity;

    void Awake() => controller = GetComponent<CharacterController>();

    void Update()
    {
        if (game.Won) return;
        var keyboard = Keyboard.current;
        Vector2 input = Vector2.zero;
        bool jumpHeld = false;
        if (keyboard != null)
        {
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y++;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y--;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x--;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x++;
            jumpHeld = keyboard.spaceKey.isPressed;
            if (keyboard.spaceKey.wasPressedThisFrame) lastJumpPressed = Time.time;
        }
        input = Vector2.ClampMagnitude(input, 1);
        bool grounded = controller.isGrounded && verticalSpeed <= 0;
        if (grounded)
        {
            lastGrounded = Time.time;
            verticalSpeed = -2;
        }
        if (Time.time - lastJumpPressed <= jumpBuffer && Time.time - lastGrounded <= coyoteTime)
        {
            verticalSpeed = jumpSpeed;
            lastJumpPressed = lastGrounded = float.NegativeInfinity;
        }
        float acceleration = verticalSpeed > 0 && !jumpHeld ? releaseGravity : gravity;
        verticalSpeed -= acceleration * Time.deltaTime;
        Vector3 movement = new Vector3(input.x * speed, verticalSpeed, input.y * speed);
        CollisionFlags flags = controller.Move(movement * Time.deltaTime);
        if ((flags & CollisionFlags.Above) != 0 && verticalSpeed > 0) verticalSpeed = 0;
        if (input.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.LookRotation(new Vector3(input.x, 0, input.y));
        if (transform.position.y < -5) game.Fall();
    }

    public void Teleport(Vector3 position)
    {
        controller.enabled = false;
        transform.SetPositionAndRotation(position, Quaternion.identity);
        controller.enabled = true;
        verticalSpeed = 0;
        lastGrounded = lastJumpPressed = float.NegativeInfinity;
        Physics.SyncTransforms();
    }
}
