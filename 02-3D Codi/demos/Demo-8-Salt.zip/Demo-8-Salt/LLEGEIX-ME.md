# Demo-8-Salt

Projecte independent: Unity 6.6 (6000.6.3f1), URP i Input System.

1. Descomprimeix tot el ZIP.
2. A Unity Hub, afegeix la carpeta Demo-8-Salt, amb Assets, Packages i ProjectSettings.
3. Obre-la amb Unity 6000.6.3f1 i espera que importi recursos i instal·li paquets.
4. Obre Assets/Scenes/DemoSalt.unity, prem Play i clica Game.
5. WASD o fletxes: moure. Espai: saltar; mantén-lo per pujar més. R: reiniciar.
6. Salta entre les illes, activa el checkpoint blau i arriba a l'esfera taronja.

En caure reapareixes al principi o al checkpoint. R reinicia tot el repte.
Hi ha 0.12 s de tolerància després de deixar una vora i abans d'aterrar.

Tutorial: Demo-8-Salt.md als apunts. Les captures són externes al ZIP.
No inclou Library, Temp ni Logs. Unity regenerarà la memòria cau.
La primera obertura requereix Internet per instal·lar els paquets i més espai en disc.
