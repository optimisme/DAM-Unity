using UnityEngine;

public class PalancaTreasure : MonoBehaviour
{
    public PalancaSwitch lever;
    private bool collected;

    void OnTriggerEnter(Collider other)
    {
        if (collected || !other.CompareTag("Player")) return;
        collected = true;
        lever.Win();
        gameObject.SetActive(false);
    }
}
