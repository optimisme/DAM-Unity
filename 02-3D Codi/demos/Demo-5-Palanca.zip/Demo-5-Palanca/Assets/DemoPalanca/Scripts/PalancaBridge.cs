using UnityEngine;
using System.Collections.Generic;

public class PalancaBridge : MonoBehaviour
{
    public Animator animator;
    public Collider deckCollider;
    public Collider[] barriers;
    private readonly HashSet<Collider> occupants = new HashSet<Collider>();
    private bool requestedOpen;
    private Collider zone;

    public bool IsOpen { get; private set; }
    public bool IsMoving { get; private set; }
    public bool IsOccupied => occupants.Count > 0;

    void Awake()
    {
        zone = GetComponent<Collider>();
    }

    void Update()
    {
        occupants.RemoveWhere(c => c == null || !c.enabled || !c.gameObject.activeInHierarchy
            || !zone.bounds.Intersects(c.bounds));
        AnimatorStateInfo state = animator.GetCurrentAnimatorStateInfo(0);
        bool transitioning = animator.IsInTransition(0);
        IsOpen = state.IsName("Base Layer.Lowered") && !transitioning;
        bool settled = state.IsName(requestedOpen ? "Base Layer.Lowered" : "Base Layer.Raised");
        IsMoving = transitioning || !settled;
        deckCollider.enabled = IsOpen && !IsMoving;
        foreach (Collider barrier in barriers) barrier.enabled = !deckCollider.enabled;
    }

    public bool TryToggle()
    {
        if (IsMoving || IsOccupied) return false;
        requestedOpen = !requestedOpen;
        IsMoving = true;
        deckCollider.enabled = false;
        foreach (Collider barrier in barriers) barrier.enabled = true;
        animator.SetBool("isOpen", requestedOpen);
        return true;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) occupants.Add(other);
    }

    void OnTriggerExit(Collider other)
    {
        occupants.Remove(other);
    }
}
