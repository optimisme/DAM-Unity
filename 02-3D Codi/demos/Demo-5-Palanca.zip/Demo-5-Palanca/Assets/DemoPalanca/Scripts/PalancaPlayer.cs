using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public class PalancaPlayer : MonoBehaviour
{
    public PalancaSwitch lever;
    public float speed = 3f;
    public float gravity = -20f;
    private CharacterController controller;
    private Vector2 moveInput;
    private float verticalSpeed;
    private Vector3 startPosition;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        startPosition = transform.position;
    }

    public void OnMove(InputValue value)
    {
        moveInput = value.Get<Vector2>();
    }

    public void OnInteract(InputValue value)
    {
        if (value.isPressed) lever.TryUse();
    }

    void Update()
    {
        Vector2 input = Vector2.ClampMagnitude(moveInput, 1f);
        Vector3 direction = new Vector3(input.x, 0f, input.y);
        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
        if (transform.position.y < -6f)
        {
            controller.enabled = false;
            transform.position = startPosition;
            controller.enabled = true;
            verticalSpeed = 0f;
        }
    }
}
