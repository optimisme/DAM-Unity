# Demo-5-Palanca

Projecte independent: Unity 6.6 (6000.6.3f1), URP i Input System.

1. Descomprimeix el ZIP.
2. A Unity Hub, afegeix la carpeta Demo-5-Palanca, que conté Assets, Packages i ProjectSettings.
3. Obre’l amb Unity 6000.6.3f1 i espera la instal·lació de paquets i la importació de recursos.
4. Obre Assets/Scenes/DemoPalanca.unity i prem Play. Clica Game.
5. WASD o fletxes mouen la càpsula; E activa la palanca quan ets a prop.
6. Abaixa el pont, espera que acabi l’animació, travessa’l i toca l’esfera.

No pots aixecar el pont mentre està ocupat. Si caus per un lateral, tornes a l’inici.
Per reiniciar tota la demo, atura Play i torna a començar.

El tutorial complet és Demo-5-Palanca.md als apunts, amb captures externes al ZIP.
El projecte no inclou captures, Library, Temp ni Logs. Unity regenerarà la memòria cau,
i descarregarà els paquets si cal: la primera obertura requereix Internet i més espai en disc.
