using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class MechanismPuzzle : MonoBehaviour
{
    public MechanismPlayer player;
    public Rigidbody box;
    public MechanismPlate plate;
    public MechanismGate gate;
    public TMP_Text statusText;
    private Vector3 boxStart;
    private Quaternion boxRotation;
    private bool won;

    void Start()
    {
        boxStart = box.position;
        boxRotation = box.rotation;
        ShowInstructions();
    }

    void Update()
    {
        var keys = Keyboard.current;
        if ((keys != null && keys.rKey.wasPressedThisFrame) ||
            player.transform.position.y < -8f || box.position.y < -8f)
            ResetPuzzle();
    }

    public void Win()
    {
        if (won) return;
        won = true;
        statusText.text = "Tresor aconseguit! Prem R per tornar a començar.";
    }

    public void ResetPuzzle()
    {
        player.ResetPosition();
        box.linearVelocity = Vector3.zero;
        box.angularVelocity = Vector3.zero;
        box.position = boxStart;
        box.rotation = boxRotation;
        plate.ResetPlate();
        gate.ResetGate();
        Physics.SyncTransforms();
        won = false;
        ShowInstructions();
    }

    void ShowInstructions()
    {
        statusText.text = "Deixa la caixa sobre la placa i arriba al tresor.";
    }
}
