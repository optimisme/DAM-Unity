using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public class MechanismPlayer : MonoBehaviour
{
    public float speed = 3f;
    public float pushSpeed = 2f;
    public float gravity = -20f;
    private CharacterController controller;
    private Vector3 startPosition;
    private float verticalSpeed;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        startPosition = transform.position;
    }

    void Update()
    {
        Vector3 direction = Vector3.zero;
        var keys = Keyboard.current;
        if (keys != null)
        {
            if (keys.wKey.isPressed || keys.upArrowKey.isPressed) direction.z += 1;
            if (keys.sKey.isPressed || keys.downArrowKey.isPressed) direction.z -= 1;
            if (keys.dKey.isPressed || keys.rightArrowKey.isPressed) direction.x += 1;
            if (keys.aKey.isPressed || keys.leftArrowKey.isPressed) direction.x -= 1;
        }
        direction = direction.normalized;
        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        Rigidbody body = hit.collider.attachedRigidbody;
        if (body == null || body.isKinematic || !body.CompareTag("Pushable")) return;
        if (hit.normal.y > 0.5f) return;
        Vector3 direction = Vector3.ProjectOnPlane(hit.moveDirection, Vector3.up).normalized;
        // Push horizontally while preserving the box's vertical velocity.
        body.linearVelocity = new Vector3(direction.x * pushSpeed,
            body.linearVelocity.y, direction.z * pushSpeed);
    }

    public void ResetPosition()
    {
        controller.enabled = false;
        transform.position = startPosition;
        controller.enabled = true;
        verticalSpeed = 0f;
    }
}
