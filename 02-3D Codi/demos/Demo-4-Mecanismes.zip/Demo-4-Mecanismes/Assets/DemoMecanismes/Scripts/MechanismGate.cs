using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class MechanismGate : MonoBehaviour
{
    public float openHeight = 3f;
    public float speed = 5f;
    private Rigidbody body;
    private Vector3 closedPosition;
    private bool open;

    void Awake()
    {
        body = GetComponent<Rigidbody>();
        closedPosition = body.position;
    }

    public void SetOpen(bool value)
    {
        open = value;
    }

    void FixedUpdate()
    {
        Vector3 target = closedPosition + (open ? Vector3.up * openHeight : Vector3.zero);
        body.MovePosition(Vector3.MoveTowards(body.position, target, speed * Time.fixedDeltaTime));
    }

    public void ResetGate()
    {
        open = false;
        body.position = closedPosition;
    }
}
