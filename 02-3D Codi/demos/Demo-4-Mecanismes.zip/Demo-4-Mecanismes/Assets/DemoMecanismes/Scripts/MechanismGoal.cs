using UnityEngine;

public class MechanismGoal : MonoBehaviour
{
    public MechanismPuzzle puzzle;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) puzzle.Win();
    }
}
