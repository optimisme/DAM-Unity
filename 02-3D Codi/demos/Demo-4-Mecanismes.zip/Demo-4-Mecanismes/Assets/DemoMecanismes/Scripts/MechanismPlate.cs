using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;

public class MechanismPlate : MonoBehaviour
{
    public Renderer plateRenderer;
    public Color pressedColor = Color.green;
    public UnityEvent<bool> onPressedChanged = new UnityEvent<bool>();
    private readonly HashSet<Collider> occupants = new HashSet<Collider>();
    private Material ownMaterial;
    private Color originalColor;
    private bool pressed;

    void Awake()
    {
        ownMaterial = plateRenderer.material;
        originalColor = ownMaterial.GetColor("_BaseColor");
    }

    bool IsWeight(Collider other)
    {
        return other.CompareTag("Player") ||
            (other.attachedRigidbody != null && other.attachedRigidbody.CompareTag("Pushable"));
    }

    void OnTriggerEnter(Collider other)
    {
        if (IsWeight(other)) occupants.Add(other);
        UpdateState();
    }

    void OnTriggerExit(Collider other)
    {
        occupants.Remove(other);
        UpdateState();
    }

    void Update()
    {
        // Disabled or destroyed objects may not send OnTriggerExit.
        occupants.RemoveWhere(c => c == null || !c.enabled || !c.gameObject.activeInHierarchy);
        UpdateState();
    }

    void UpdateState()
    {
        bool next = occupants.Count > 0;
        if (next == pressed) return;
        pressed = next;
        ownMaterial.SetColor("_BaseColor", pressed ? pressedColor : originalColor);
        onPressedChanged.Invoke(pressed);
    }

    public void ResetPlate()
    {
        occupants.Clear();
        pressed = false;
        ownMaterial.SetColor("_BaseColor", originalColor);
        onPressedChanged.Invoke(false);
    }

    void OnDestroy()
    {
        if (ownMaterial != null) Destroy(ownMaterial);
    }
}
