using UnityEngine;
using System.Collections;

public class ItemGenerator : MonoBehaviour
{
    public GameObject itemPrefab;
    public float generateDelay = 2f;

    private GameObject currentItem;

    void Start()
    {
        Generate();
    }

    void Generate()
    {
        currentItem = Instantiate(
            itemPrefab,
            transform.position,
            Quaternion.identity
        );

        Collectable collectable = currentItem.GetComponent<Collectable>();
        collectable.generator = this;
    }

    public void ItemCollected()
    {
        currentItem = null;
        StartCoroutine(GenerateDelayed());
    }

    IEnumerator GenerateDelayed()
    {
        yield return new WaitForSeconds(generateDelay);
        Generate();
    }
}
