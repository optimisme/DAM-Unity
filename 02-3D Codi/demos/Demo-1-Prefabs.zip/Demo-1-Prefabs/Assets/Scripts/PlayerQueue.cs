using UnityEngine;
using System.Collections.Generic;

public class PlayerQueue : MonoBehaviour
{
    public float distance = 0.6f;
    public float followSpeed = 10f;

    private List<Transform> items = new List<Transform>();

    // Add an item to the queue
    public void AddItem(Transform item)
    {
        items.Add(item);
    }

    // Update the queue after the player has moved
    void LateUpdate()
    {
        Transform target = transform;

        // Each item follows the previous one
        foreach (Transform item in items)
        {
            Vector3 direction = item.position - target.position;

            if (direction.magnitude > distance)
            {
                Vector3 targetPosition =
                    target.position + direction.normalized * distance;

                item.position = Vector3.Lerp(
                    item.position,
                    targetPosition,
                    followSpeed * Time.deltaTime
                );
            }

            target = item;
        }
    }
}
