using UnityEngine;

public class Collectable : MonoBehaviour
{
    public ItemGenerator generator;

    private bool collected = false;

    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Trigger detectat amb: " + other.name);

        if (collected || !other.CompareTag("Player"))
            return;

        collected = true;

        PlayerQueue queue = other.GetComponent<PlayerQueue>();
        queue.AddItem(transform);
        Debug.Log("Objecte recollit!");

        if (generator != null)
            generator.ItemCollected();
    }
}
