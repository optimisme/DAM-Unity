using UnityEngine;
using TMPro;

public class DioramaProgress : MonoBehaviour
{
    public int total = 3;
    public Transform door;
    public TMP_Text statusText;
    public float openHeight = 2.5f;
    private int collected;
    private Vector3 closedPosition;
    private bool won;
    public bool IsOpen => collected >= total;

    void Start()
    {
        closedPosition = door.position;
        UpdateText();
    }

    void Update()
    {
        if (IsOpen)
            door.position = Vector3.MoveTowards(door.position,
                closedPosition + Vector3.up * openHeight, 2f * Time.deltaTime);
    }

    public void Collect()
    {
        collected++;
        UpdateText();
    }

    public void ReachTreasure()
    {
        if (!IsOpen || won) return;
        won = true;
        UpdateText();
    }

    void UpdateText()
    {
        statusText.text = won ? "Tresor aconseguit!" :
            $"Esferes: {collected}/{total}" + (IsOpen ? "  —  Porta oberta!" : "");
    }
}
