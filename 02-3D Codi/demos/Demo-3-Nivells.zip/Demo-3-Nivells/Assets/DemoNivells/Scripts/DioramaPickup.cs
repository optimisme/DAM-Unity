using UnityEngine;

public class DioramaPickup : MonoBehaviour
{
    public DioramaProgress progress;
    public bool isTreasure;
    private bool collected;

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || collected) return;
        if (isTreasure)
        {
            progress.ReachTreasure();
            return;
        }
        collected = true;
        progress.Collect();
        gameObject.SetActive(false);
    }
}
