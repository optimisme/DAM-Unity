using UnityEngine;
using UnityEngine.InputSystem;

[DefaultExecutionOrder(100)]
public class DioramaCamera : MonoBehaviour
{
    public Transform pivot;
    public float distance = 24f;
    public float pitch = 35f;
    public float turnSpeed = 180f;
    private float yaw = 45f;
    private float targetYaw = 45f;

    void LateUpdate()
    {
        var keys = Keyboard.current;
        if (keys != null)
        {
            if (keys.qKey.wasPressedThisFrame) targetYaw -= 90f;
            if (keys.eKey.wasPressedThisFrame) targetYaw += 90f;
        }
        yaw = Mathf.MoveTowardsAngle(yaw, targetYaw, turnSpeed * Time.deltaTime);
        transform.rotation = Quaternion.Euler(pitch, yaw, 0f);
        transform.position = pivot.position - transform.forward * distance;
    }
}
