using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public class DioramaPlayer : MonoBehaviour
{
    public Transform viewCamera;
    public float speed = 3f;
    public float gravity = -20f;
    private CharacterController controller;
    private DioramaLift support;
    private Vector3 startPosition;
    private float verticalSpeed;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
        startPosition = transform.position;
    }

    void Update()
    {
        // Apply the displacement of the platform from the previous contact.
        if (support != null) controller.Move(support.Delta);
        support = null;

        Vector2 input = Vector2.zero;
        var keys = Keyboard.current;
        if (keys != null)
        {
            if (keys.wKey.isPressed || keys.upArrowKey.isPressed) input.y += 1;
            if (keys.sKey.isPressed || keys.downArrowKey.isPressed) input.y -= 1;
            if (keys.dKey.isPressed || keys.rightArrowKey.isPressed) input.x += 1;
            if (keys.aKey.isPressed || keys.leftArrowKey.isPressed) input.x -= 1;
        }
        input = Vector2.ClampMagnitude(input, 1f);
        Vector3 forward = Vector3.ProjectOnPlane(viewCamera.forward, Vector3.up).normalized;
        Vector3 right = Vector3.ProjectOnPlane(viewCamera.right, Vector3.up).normalized;
        Vector3 direction = forward * input.y + right * input.x;

        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
        if (direction.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(direction);

        // A fall restarts the position, but keeps the collected spheres.
        if (transform.position.y < -8f)
        {
            controller.enabled = false;
            transform.position = startPosition;
            controller.enabled = true;
            verticalSpeed = 0f;
            support = null;
        }
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.normal.y > 0.5f)
            support = hit.collider.GetComponent<DioramaLift>();
    }
}
