using UnityEngine;
using System.Collections.Generic;

[DefaultExecutionOrder(200)]
public class DioramaOcclusion : MonoBehaviour
{
    public Transform player;
    public LayerMask wallsMask;
    private DioramaWall[] walls;
    private readonly HashSet<DioramaWall> obstructing = new HashSet<DioramaWall>();

    void Start()
    {
        walls = FindObjectsByType<DioramaWall>();
    }

    void LateUpdate()
    {
        obstructing.Clear();
        // In perspective, trace the line from the camera to the player.
        Vector3 origin = transform.position;
        Vector3 toPlayer = player.position - origin;
        float distance = toPlayer.magnitude;
        Vector3 direction = distance > 0.001f ? toPlayer / distance : transform.forward;
        RaycastHit[] hits = Physics.SphereCastAll(origin, 0.25f, direction,
            distance, wallsMask, QueryTriggerInteraction.Ignore);
        foreach (RaycastHit hit in hits)
        {
            DioramaWall wall = hit.collider.GetComponent<DioramaWall>();
            if (wall != null) obstructing.Add(wall);
        }
        foreach (DioramaWall wall in walls)
            if (wall != null) wall.SetObstructing(obstructing.Contains(wall));
    }
}
