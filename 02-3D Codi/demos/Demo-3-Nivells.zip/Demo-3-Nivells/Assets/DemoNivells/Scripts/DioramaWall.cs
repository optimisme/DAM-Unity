using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class DioramaWall : MonoBehaviour
{
    [Range(0f, 1f)] public float hiddenAlpha = 0.25f;
    public float fadeSpeed = 3f;
    private Material ownMaterial;
    private Color originalColor;

    void Awake()
    {
        // Each wall has its own instance: fading one does not fade the others.
        ownMaterial = GetComponent<Renderer>().material;
        originalColor = ownMaterial.GetColor("_BaseColor");
    }

    public void SetObstructing(bool obstructing)
    {
        Color color = ownMaterial.GetColor("_BaseColor");
        float target = obstructing ? hiddenAlpha : originalColor.a;
        color.a = Mathf.MoveTowards(color.a, target, fadeSpeed * Time.deltaTime);
        ownMaterial.SetColor("_BaseColor", color);
    }

    void OnDestroy()
    {
        if (ownMaterial != null) Destroy(ownMaterial);
    }
}
