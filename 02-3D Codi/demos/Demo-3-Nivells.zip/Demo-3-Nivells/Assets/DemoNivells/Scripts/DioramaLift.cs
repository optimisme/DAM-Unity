using UnityEngine;

[DefaultExecutionOrder(-100)]
public class DioramaLift : MonoBehaviour
{
    public Transform bottom;
    public Transform top;
    public float speed = 1.2f;
    public float waitTime = 2f;
    public Vector3 Delta { get; private set; }
    private bool goingUp = true;
    private float remainingWait;

    void Start()
    {
        transform.position = bottom.position;
        remainingWait = waitTime;
    }

    void Update()
    {
        Vector3 previous = transform.position;
        if (remainingWait > 0f) remainingWait -= Time.deltaTime;
        else
        {
            Vector3 target = goingUp ? top.position : bottom.position;
            transform.position = Vector3.MoveTowards(previous, target, speed * Time.deltaTime);
            if (Vector3.Distance(transform.position, target) < 0.001f)
            {
                goingUp = !goingUp;
                remainingWait = waitTime;
            }
        }
        Delta = transform.position - previous;
    }
}
