using UnityEngine;
using UnityEditor;
using System.IO;

public static class GenerarFonsGalaxy
{
    // Crea una opció de menú de l'Editor per generar la superfície del fons.
    [MenuItem("Demos/Crear fons inclinat Galaxy")]
    public static void Crear()
    {
        // Quatre vèrtexs són suficients: aquest shader no deforma la geometria.
        var mesh = new Mesh { name = "FonsInclinat" };
        mesh.vertices = new[] {
            new Vector3(-4, .45f, -2.5f), new Vector3(4, -.7f, -2.5f),
            new Vector3(-4, .45f, 2.5f), new Vector3(4, -.7f, 2.5f)
        };
        // Assigna les quatre cantonades UV per estendre el patró per tota la superfície.
        mesh.uv = new[] { Vector2.zero, Vector2.right, Vector2.up, Vector2.one };
        // Forma el rectangle amb dos triangles que comparteixen una diagonal.
        mesh.triangles = new[] { 0, 2, 1, 1, 2, 3 };
        // Actualitza l'orientació de la superfície i els límits de la malla acabada de crear.
        mesh.RecalculateNormals(); mesh.RecalculateTangents(); mesh.RecalculateBounds();
        Directory.CreateDirectory("Assets/Meshes");
        AssetDatabase.CreateAsset(mesh, AssetDatabase.GenerateUniqueAssetPath("Assets/Meshes/FonsInclinat.asset"));
        AssetDatabase.SaveAssets();
        // Selecciona la malla creada perquè es pugui veure a l'Inspector.
        Selection.activeObject = mesh;
    }
}
