# Demo 8: Pèls

Unity 6000.6.3f1 · Universal RP / Shader Graph 17.6.0 · Input System 1.20.0.

Afegeix aquesta carpeta a Unity Hub. Espera que acabi la importació. S’obre DemoPels automàticament el primer cop; també pots usar Demo > Obrir escena principal.

Prem Play i clica Game. Esquerra: shells amb ratlles. Dreta: POM amb curvatura.

Lliscador: llargada comuna. Botons: capes / passos. C: curvatura. R: reinicia. H: panell. Botó dret: orbita. Roda: zoom. Home: càmera inicial.

Els grafs són a Assets/Demos/Pels/Shaders. Pels.hlsl conté les funcions del color i del POM. Els scripts són a Scripts i Assets/Common. La textura de pèl fi, de 2048×1024, és a Textures. El generador permet regenerar-la des de Demos > Pels > 1 - Generar malla i mapa.

Vídeo de referència: https://www.youtube.com/watch?v=SSoedKq6wt0
Tutorial: ../Demo-8-Pels.md al repositori DAM-Unity, carpeta 04-Shaders.

El POM està preparat per a l’esfera de radi 1 inclosa. No és un shader genèric per a qualsevol malla. No projecta ombres de pèl ni escriu la profunditat del punt trobat.
