using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

[InitializeOnLoad]
public static class DemoPelsStartup
{
    const string ScenePath = "Assets/Demos/Pels/Scenes/DemoPels.unity";
    static DemoPelsStartup() { EditorApplication.update += FirstOpen; }
    static void FirstOpen()
    {
        if (Application.isBatchMode || EditorApplication.isCompiling || EditorApplication.isUpdating) return;
        string key = "DAM.Pels.FirstOpen." + Application.dataPath;
        if (EditorPrefs.GetBool(key, false)) { EditorApplication.update -= FirstOpen; return; }
        if (!AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath)) return;
        EditorPrefs.SetBool(key, true);
        EditorApplication.update -= FirstOpen;
        if (!EditorSceneManager.GetActiveScene().isDirty) Open();
    }
    [MenuItem("Demo/Obrir escena principal")]
    public static void Open()
    {
        if (!EditorApplication.isPlaying && EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            EditorSceneManager.OpenScene(ScenePath);
    }
}
