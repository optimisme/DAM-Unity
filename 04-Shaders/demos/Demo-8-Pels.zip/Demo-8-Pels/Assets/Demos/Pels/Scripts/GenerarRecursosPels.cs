#if UNITY_EDITOR
using System.IO;
using UnityEngine;
using UnityEditor;

public static class GenerarRecursosPels
{
    public const string Root = "Assets/Demos/Pels";
    [MenuItem("Demos/Pels/1 - Generar malla i mapa")]
    public static void Generate()
    {
        Directory.CreateDirectory(Root + "/Meshes");
        Directory.CreateDirectory(Root + "/Textures");
        const int columns = 128, rows = 64;
        var vertices = new Vector3[(columns + 1) * (rows + 1)];
        var normals = new Vector3[vertices.Length];
        var uv = new Vector2[vertices.Length];
        var triangles = new int[columns * rows * 6];
        for (int y = 0; y <= rows; y++) for (int x = 0; x <= columns; x++)
        {
            float u = x / (float)columns, v = y / (float)rows;
            float lon = (u - .5f) * Mathf.PI * 2, lat = (v - .5f) * Mathf.PI;
            int i = y * (columns + 1) + x;
            vertices[i] = normals[i] = new Vector3(Mathf.Cos(lat) * Mathf.Cos(lon), Mathf.Sin(lat), Mathf.Cos(lat) * Mathf.Sin(lon));
            uv[i] = new Vector2(u, v);
        }
        int k = 0;
        for (int y = 0; y < rows; y++) for (int x = 0; x < columns; x++)
        {
            int a = y * (columns + 1) + x, b = a + columns + 1;
            triangles[k++] = a; triangles[k++] = b; triangles[k++] = a + 1;
            triangles[k++] = a + 1; triangles[k++] = b; triangles[k++] = b + 1;
        }
        var mesh = new Mesh { name = "EsferaRadi1", vertices = vertices, normals = normals, uv = uv, triangles = triangles };
        mesh.RecalculateTangents();
        // La GPU extrudeix fins a 0.25: amplia el culling, sense alterar els vertexs.
        mesh.bounds = new Bounds(Vector3.zero, Vector3.one * 2.6f);
        string meshPath = Root + "/Meshes/EsferaRadi1.asset";
        var existing = AssetDatabase.LoadAssetAtPath<Mesh>(meshPath);
        if (existing) { EditorUtility.CopySerialized(mesh, existing); Object.DestroyImmediate(mesh); }
        else AssetDatabase.CreateAsset(mesh, meshPath);
        const int width = 2048, height = 1024, cell = 8;
        var tex = new Texture2D(width, height, TextureFormat.RGB24, false, true);
        var pixels = new Color[width * height];
        var random = new System.Random(831);
        for (int cy = 0; cy < height / cell; cy++) for (int cx = 0; cx < width / cell; cx++)
        {
            float centerX = 3.5f + ((float)random.NextDouble() - .5f) * 4.2f;
            float centerY = 3.5f + ((float)random.NextDouble() - .5f) * 4.2f;
            float tip = .35f + (float)random.NextDouble() * .65f;
            for (int y = 0; y < cell; y++) for (int x = 0; x < cell; x++)
            {
                float distance = new Vector2(x - centerX, y - centerY).magnitude;
                float h = tip * Mathf.Pow(Mathf.Clamp01(1 - distance / 2.2f), .35f);
                pixels[(cy * cell + y) * width + cx * cell + x] = new Color(h, h, h);
            }
        }
        tex.SetPixels(pixels); tex.Apply();
        string path = Root + "/Textures/MapaPels.png";
        File.WriteAllBytes(path, tex.EncodeToPNG()); Object.DestroyImmediate(tex);
        AssetDatabase.ImportAsset(path);
        var importer = (TextureImporter)AssetImporter.GetAtPath(path);
        importer.sRGBTexture = false; importer.mipmapEnabled = true;
        importer.textureCompression = TextureImporterCompression.Uncompressed;
        importer.wrapModeU = TextureWrapMode.Repeat; importer.wrapModeV = TextureWrapMode.Clamp;
        importer.filterMode = FilterMode.Bilinear; importer.maxTextureSize = 2048;
        importer.SaveAndReimport(); AssetDatabase.SaveAssets();
    }
}
#endif
