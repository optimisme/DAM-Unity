using UnityEngine;
using UnityEngine.InputSystem;

public class PelsController : MonoBehaviour
{
    public PelsShells shells;
    public Renderer pom;
    public Camera viewCamera;
    public bool showPanel = true;
    public bool curvature = true;
    [Range(16,256)] public int steps = 128;
    MaterialPropertyBlock block;
    Rect Panel => new Rect(16,16,580,220);
    void Awake()
    {
        block = new MaterialPropertyBlock();
        var orbit = viewCamera.GetComponent<DemoOrbitCamera>();
        if (orbit) orbit.IsPointerOverControls = p => showPanel && Panel.Contains(p);
        Apply();
    }
    public void Apply()
    {
        if (block == null) block = new MaterialPropertyBlock();
        block.Clear(); block.SetFloat("_Llargada", shells.length);
        block.SetFloat("_Passos", steps); block.SetFloat("_Curvatura", curvature ? 1 : 0);
        pom.SetPropertyBlock(block); shells.Apply();
    }
    void Update()
    {
        var k = Keyboard.current;
        if (k != null)
        {
            if (k.hKey.wasPressedThisFrame) showPanel = !showPanel;
            if (k.cKey.wasPressedThisFrame) curvature = !curvature;
            if (k.rKey.wasPressedThisFrame)
            {
                shells.length = .16f; shells.layers = 40; shells.Rebuild();
                steps = 128; curvature = true; viewCamera.GetComponent<DemoOrbitCamera>().ResetView();
            }
        }
        Apply();
    }
    void OnGUI()
    {
        if (!showPanel) return;
        GUI.Box(Panel, "");
        GUILayout.BeginArea(new Rect(30,25,552,202));
        GUILayout.Label("08 / PELS    Esquerra: SHELLS    Dreta: POM AMB CURVATURA");
        GUILayout.Label("Boto dret: orbita | Roda: zoom | Home: vista inicial | H: panell");
        GUILayout.Label("Llargada comuna: " + shells.length.ToString("0.00"));
        shells.length = GUILayout.HorizontalSlider(shells.length,.01f,.25f);
        GUILayout.BeginHorizontal();
        GUILayout.Label("Capes: " + shells.layers);
        foreach(int count in new[]{8,24,40,64})
            if(GUILayout.Button(count.ToString())) { shells.layers=count; shells.Rebuild(); }
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        GUILayout.Label("Passos POM: " + steps);
        foreach(int count in new[]{32,64,128,256}) if(GUILayout.Button(count.ToString())) steps=count;
        GUILayout.EndHorizontal();
        curvature = GUILayout.Toggle(curvature,"C: curvatura i retall de silueta    |    R: reiniciar");
        GUILayout.EndArea();
    }
}
