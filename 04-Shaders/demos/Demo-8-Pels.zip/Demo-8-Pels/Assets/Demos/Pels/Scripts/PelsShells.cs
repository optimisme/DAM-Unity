using UnityEngine;
using UnityEngine.Rendering;

[ExecuteAlways]
public class PelsShells : MonoBehaviour
{
    public Mesh mesh;
    public Material material;
    [Range(4, 64)] public int layers = 40;
    [Range(.01f, .25f)] public float length = .16f;
    [Range(0, 1)] public float stripes = 1;
    MaterialPropertyBlock block;

    [ContextMenu("Reconstruir capes")]
    public void Rebuild()
    {
        // Aquest objecte nomes ha de contenir les capes generades.
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            var child = transform.GetChild(i).gameObject;
            child.SetActive(false);
            if (Application.isPlaying) Destroy(child); else DestroyImmediate(child);
        }
        if (!mesh || !material) return;
        for (int i = 0; i <= layers; i++)
        {
            var go = new GameObject(i == 0 ? "Base" : "Shell " + i.ToString("00"));
            go.transform.SetParent(transform, false);
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            var renderer = go.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = material; renderer.sortingOrder = i;
            renderer.shadowCastingMode = ShadowCastingMode.Off; renderer.receiveShadows = false;
        }
        Apply();
    }
    void OnEnable() { Apply(); }
    void OnValidate() { layers = Mathf.Clamp(layers, 4, 64); length = Mathf.Clamp(length, .01f, .25f); }
    public void Apply()
    {
        if (block == null) block = new MaterialPropertyBlock();
        int count = 0;
        foreach (Transform child in transform)
        {
            if (!child.gameObject.activeSelf) continue;
            var renderer = child.GetComponent<Renderer>();
            if (!renderer) continue;
            block.Clear(); block.SetFloat("_Capa", count / (float)layers);
            block.SetFloat("_Llargada", length); block.SetFloat("_Ratlles", stripes);
            renderer.SetPropertyBlock(block); count++;
        }
    }
    void Update() { Apply(); }
}
