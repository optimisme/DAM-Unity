#ifndef DAM_PELS_INCLUDED
#define DAM_PELS_INCLUDED
// Mapa esferic coherent amb GenerarRecursosPels: eix vertical Y, radi base 1.
float2 PelsUV(float3 p)
{
    float3 n = normalize(p);
    return float2(atan2(n.z, n.x) / 6.28318530718 + 0.5,
                  asin(clamp(n.y, -1.0, 1.0)) / 3.14159265359 + 0.5);
}
float PelsHeight(UnityTexture2D Map, float2 uv)
{
    return SAMPLE_TEXTURE2D_LOD(Map.tex, Map.samplerstate, uv, 0).r;
}
void PelsColor_float(float3 PosOS, float3 ViewOS, float Height, float Stripes,
                     float3 Gold, float3 Dark, out float3 Color)
{
    float3 n = normalize(PosOS);
    float stripe = smoothstep(-0.15, 0.15, sin(n.y * 14.0 + 0.4));
    float3 tint = lerp(Gold, lerp(Dark, Gold, stripe), saturate(Stripes));
    // Il·luminacio artistica en espai objecte, compartida per les dues tecniques.
    float diffuse = saturate(dot(n, normalize(float3(-0.45, 0.8, -0.65))));
    float rim = pow(1.0 - saturate(dot(n, normalize(ViewOS))), 3.0);
    Color = tint * (0.28 + 0.72 * diffuse) * lerp(0.35, 1.15, saturate(Height))
          + Gold * rim * 0.12;
}
// Distance > 0: el raig encara es troba per sobre del mapa d'altures.
float PelsDistance(UnityTexture2D Map, float3 p, float3 n, float3 tangent,
                   float3 bitangent, float2 uv0, float Length, float Curvature)
{
    float radial = lerp(dot(p, n), length(p), saturate(Curvature));
    float3 delta = p - n * (1.0 + Length);
    float2 flatUV = uv0 + float2(dot(delta, tangent) /
        (6.28318530718 * max(0.05, length(n.xz))), dot(delta, bitangent) / 3.14159265359);
    float2 uv = Curvature > 0.5 ? PelsUV(p) : flatUV;
    return radial - (1.0 + Length * PelsHeight(Map, uv));
}
void PelsPOM_float(UnityTexture2D Map, float3 PosOS, float3 ViewOS,
                    float Length, float Steps, float Curvature,
                    out float3 HitOS, out float Height, out float Alpha)
{
    Length = max(Length, 0.0001);
    float3 n = normalize(PosOS);
    float3 start = n * (1.0 + Length);
    float3 ray = -normalize(ViewOS);
    float3 tangent = normalize(float3(-n.z, 0, n.x) + float3(1e-6,0,0));
    float3 bitangent = normalize(cross(tangent, n));
    float2 uv0 = PelsUV(n);
    // Sortida de l'esfera exterior: evita continuar el raig fora del volum.
    float maxTravel = max(0.0, -2.0 * dot(start, ray));
    if (Curvature < 0.5) maxTravel = min(2.5, Length / max(0.025, -dot(n, ray)));
    int count = (int)clamp(Steps, 16.0, 256.0);
    float stride = maxTravel / count;
    HitOS = start; Height = 1.0; Alpha = 0.0;
    float previous = 0.0;
    [loop] for (int i = 0; i <= count; ++i)
    {
        float travel = i * stride;
        float3 p = start + ray * travel;
        if (PelsDistance(Map, p, n, tangent, bitangent, uv0, Length, Curvature) <= 0.0)
        {
            float low = previous, high = travel;
            // Refina el primer encreuament; no recupera fils saltats entre mostres.
            [unroll] for (int j = 0; j < 5; ++j)
            {
                float mid = (low + high) * 0.5;
                if (PelsDistance(Map, start + ray * mid, n, tangent, bitangent, uv0, Length, Curvature) > 0.0)
                    low = mid;
                else high = mid;
            }
            HitOS = start + ray * high;
            float radial = Curvature > 0.5 ? length(HitOS) : dot(HitOS, n);
            Height = saturate((radial - 1.0) / Length);
            Alpha = 1.0;
            return;
        }
        previous = travel;
    }
    // Sense interseccio: Alpha Clipping deixa veure el fons.
}
#endif
