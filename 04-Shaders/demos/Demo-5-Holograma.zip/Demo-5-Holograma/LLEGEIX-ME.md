# Demo-5-Holograma

Unity 6000.6.3f1 · Universal RP / Shader Graph 17.6.0 · Input System 1.20.0.

1. Descomprimeix i afegeix la carpeta amb Assets, Packages i ProjectSettings a Unity Hub.
2. En acabar la importació s’obre automàticament `Assets/Demos/Holograma/Scenes/DemoHolograma.unity`. Els materials poden trigar una estona a carregar-se.
3. Prem Play i clica Game. Botó dret + arrossegar: orbita; roda: zoom; Home: vista inicial; H: panell.

Demo > Obrir escena principal permet recuperar l’escena. Les obertures següents respecten la feina desada.

Tutorials a 03-Shaders del repositori DAM-Unity.
