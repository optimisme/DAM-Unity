using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

// El codi detecta parets; el shader conserva només els píxels ocults del personatge.
public class SombraController : MonoBehaviour
{
    public Camera viewCamera;
    public Transform player;
    public Renderer[] walls;
    public Renderer[] silhouettes;
    public LayerMask wallMask = 1 << 8;
    public Vector3 targetOffset = new Vector3(0, 1.2f, 0);
    public bool effectEnabled = true;
    public bool autoMove = true;
    public bool showPanel = true;
    public int activeWalls;
    float elapsed;
    Vector3 initialPosition;

    void Awake()
    {
        initialPosition = player.position;
        var orbit = viewCamera.GetComponent<DemoOrbitCamera>();
        if (orbit) orbit.IsPointerOverControls = p => showPanel && new Rect(16, 16, 510, 114).Contains(p);
    }

    void Update()
    {
        elapsed += Time.deltaTime;
        var k = Keyboard.current;
        if (k != null)
        {
            if (k.fKey.wasPressedThisFrame) effectEnabled = !effectEnabled;
            if (k.spaceKey.wasPressedThisFrame) autoMove = !autoMove;
            if (k.hKey.wasPressedThisFrame) showPanel = !showPanel;
            float direction = (k.dKey.isPressed ? 1 : 0) - (k.aKey.isPressed ? 1 : 0);
            if (direction != 0)
            {
                autoMove = false;
                Vector3 p = player.position;
                p.x = Mathf.Clamp(p.x + direction * Time.deltaTime * 2, -4, 4);
                player.position = p;
            }
            if (k.rKey.wasPressedThisFrame) ResetDemo();
        }
        if (autoMove)
            player.position = new Vector3(initialPosition.x + Mathf.Sin(elapsed * .6f) * 4,
                initialPosition.y, initialPosition.z);
    }

    void LateUpdate() { RefreshSilhouette(); }

    public void ResetDemo()
    {
        elapsed = 0; autoMove = true; effectEnabled = true;
        player.position = initialPosition;
    }

    public void RefreshSilhouette()
    {
        Vector3 target = player.position + targetOffset;
        Physics.SyncTransforms();
        activeWalls = 0;
        if (effectEnabled && viewCamera.WorldToViewportPoint(target).z > 0)
        {
            // Prova el tronc i el centre de cada peça: també detecta braços o cames ocults.
            var targets = new List<Vector3> { target };
            foreach (Renderer silhouette in silhouettes)
                if (silhouette) targets.Add(silhouette.bounds.center);
            var blocked = new HashSet<Renderer>();
            foreach (Vector3 point in targets)
            {
                Vector3 segment = point - viewCamera.transform.position;
                var hits = Physics.RaycastAll(viewCamera.transform.position, segment.normalized,
                    segment.magnitude, wallMask, QueryTriggerInteraction.Ignore);
                foreach (RaycastHit hit in hits)
                    foreach (Renderer wall in walls)
                        if (wall && hit.collider.GetComponent<Renderer>() == wall) blocked.Add(wall);
            }
            activeWalls = blocked.Count;
        }
        foreach (Renderer silhouette in silhouettes)
            if (silhouette) silhouette.enabled = activeWalls > 0;
    }

    void OnDisable()
    {
        if (silhouettes == null) return;
        foreach (Renderer silhouette in silhouettes)
            if (silhouette) silhouette.enabled = false;
    }

    void OnGUI()
    {
        if (!showPanel) return;
        GUI.Box(new Rect(16, 16, 510, 114), "");
        GUILayout.BeginArea(new Rect(30, 25, 482, 94));
        GUILayout.Label("07 / SOMBRA — Parets davant: " + activeWalls);
        GUILayout.Label("A / D: moure | F: silueta | Espai: automatic | R: reinicia");
        GUILayout.Label("Boto dret: orbita | Roda: zoom | Home: vista inicial | H: panell");
        GUILayout.EndArea();
    }
}
