# Demo-7-Sombra

Unity 6000.6.3f1 · Universal RP i Shader Graph 17.6.0 · Input System 1.20.0.

Descomprimeix i afegeix la carpeta amb Assets, Packages i ProjectSettings a Unity Hub. En acabar la importació s’obre DemoSombra. Els materials poden trigar una estona a carregar-se.

Play i clica Game. A/D: moure; Espai: automàtic/manual; F: silueta; R: reinicia; H: panell. Botó dret: orbita; roda: zoom; Home: vista inicial.

La silueta grisa només omple els píxels ocults del personatge. La paret es manté opaca. Ajusta Color silueta i Marge profunditat al material MSilueta. Depth Texture ha d’estar activat.

Demo > Obrir escena principal recupera la demo. Tutorial: 03-Shaders/Demo-7-Sombra.md al repositori DAM-Unity.
