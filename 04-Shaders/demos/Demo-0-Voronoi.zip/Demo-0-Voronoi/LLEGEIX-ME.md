# Demo 0: Voronoi animat

Obre aquesta carpeta des de Unity Hub. L’escena principal és Assets/Scenes/SegonShader.unity; també la pots obrir amb Demo > Obrir escena principal.

Prem Play per veure el cub animat. Selecciona Assets/Materials/MVoronoiAnimat.mat i modifica Color i Velocitat (X, Y). El valor inicial és (1, 1); (0, 0) atura el patró. No cal cap script de controls.

El graf editable és Assets/Shaders/SVoronoiAnimat.shadergraph. Tutorial: https://github.com/optimisme/DAM-Unity/blob/main/04-Shaders/Demo-0-Voronoi.md
