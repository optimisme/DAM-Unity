using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

// La càmera del tutorial es mou a LateUpdate amb ordre 0.
// Actualitzem el decorat després, amb la posició definitiva de la càmera.
[DefaultExecutionOrder(100)]
public class ParallaxTilemapLayer : MonoBehaviour
{
    [SerializeField] private Camera targetCamera;
    [SerializeField] private Tilemap source;
    [SerializeField, Min(1)] private int blockWidthCells = 12;
    [SerializeField, Range(0f, 2f)] private float depth = 0.2f;
    [SerializeField] private bool followCameraY = true;
    [SerializeField] private bool mirrorAlternateBlocks = true;

    private readonly List<Transform> copies = new List<Transform>();
    private Vector3 cameraStart;
    private Vector3 layerStart;
    private float blockWidth;

    void Start()
    {
        if (!targetCamera) targetCamera = Camera.main;
        var grid = GetComponent<Grid>();
        if (!targetCamera || !targetCamera.orthographic || !source || !grid)
        {
            Debug.LogError("Assigna una càmera ortogràfica i un Tilemap fill d'aquest Grid.", this);
            enabled = false;
            return;
        }
        // El tutorial utilitza Grid amb escala 1, sense rotació ni separació entre cel·les.
        blockWidth = blockWidthCells * grid.cellSize.x;
        if (blockWidth <= 0f) { enabled = false; return; }
        cameraStart = targetCamera.transform.position;
        layerStart = transform.position;
        copies.Add(source.transform);
        UpdateLayer();
    }

    void LateUpdate() => UpdateLayer();

    private void UpdateLayer()
    {
        Vector3 cameraNow = targetCamera.transform.position;
        Vector3 delta = cameraNow - cameraStart;
        // depth descriu el moviment APARENT respecte al terreny:
        // 0 = fix a pantalla; 1 = com el terreny; >1 = primer pla.
        transform.position = layerStart + new Vector3(
            delta.x * (1f - depth), followCameraY ? delta.y : 0f, 0f);

        float halfView = targetCamera.orthographicSize * targetCamera.aspect;
        float cameraLocalX = cameraNow.x - transform.position.x;
        int first = Mathf.FloorToInt((cameraLocalX - halfView) / blockWidth) - 1;
        int last = Mathf.FloorToInt((cameraLocalX + halfView) / blockWidth) + 1;
        int needed = last - first + 1;

        // Només creem còpies quan augmenta l'amplada visible, no a cada fotograma.
        while (copies.Count < needed)
        {
            var copy = Instantiate(source.gameObject, transform).transform;
            copy.name = source.name + "_Repeat_" + copies.Count;
            copies.Add(copy);
        }
        for (int i = 0; i < copies.Count; i++)
        {
            bool used = i < needed;
            copies[i].gameObject.SetActive(used);
            if (!used) continue;
            int index = first + i;
            bool mirrored = mirrorAlternateBlocks && (index & 1) != 0;
            // Amb mirall, el costat dret toca una còpia del mateix costat dret.
            // El desplaçament d'una amplada compensa l'escala X negativa.
            copies[i].localPosition = new Vector3(
                (index + (mirrored ? 1 : 0)) * blockWidth, 0f, 0f);
            copies[i].localScale = new Vector3(mirrored ? -1f : 1f, 1f, 1f);
        }
    }
}
