# ParallaxTiles

Pack per a Unity 6 / Universal 2D. Copia aquesta carpeta a `Assets/ParallaxTiles` i executa **Tools > Parallax > Build Tiles and Prefab**. Arrossega `Generated/Parallax.prefab` a l'escena.

Quatre PNG de 2172 × 724 (Clouds: 2171 × 724; l'eina compensa el píxel transparent absent) (núvols, bosc i primer pla transparents), retallats en 12 × 4 sprites de 181 × 181 (última columna de Clouds: 180 × 181 amb pivot compensat); 192 recursos Tile decoratius i un tile de cel i un de base del bosc. L'eina genera també el material Unlit i el prefab de cinc capes. No incorpora el personatge ni el terreny originals.

Els blocs alternen el mirall horitzontal per fer coincidir les vores. Mantén escala 1, rotació 0, Grid de 2 × 2, PPU 90.5, Source a posició local zero i Block Width Cells = 12. No són tiles intercanviables lliurement. El sistema repeteix horitzontalment; no genera nivells verticals infinits.

Tutorial complet: `../10-Parallax.md`. Art generat amb IA. No s'han substituït els assets originals del personatge ni del terreny.
