using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.U2D.Sprites;
using UnityEngine;
using UnityEngine.Tilemaps;

public static class ParallaxTilesBuilder
{
    private const string Root = "Assets/ParallaxTiles";
    private const int TilePixels = 181;

    [MenuItem("Tools/Parallax/Build Tiles and Prefab")]
    public static void Build()
    {
        Directory.CreateDirectory(Root + "/Generated");
        var parent = new GameObject("Parallax");
        try
        {
            CreateSky(parent.transform);
            CreateLayer(parent.transform, "Mountains", -80, .2f, -1f);
            CreateLayer(parent.transform, "Clouds", -60, .3f, -1.6f);
            CreateLayer(parent.transform, "Forest", -40, .55f, -3.7f);
            CreateLayer(parent.transform, "Foreground", 40, 1.2f, -4.9f);
            PrefabUtility.SaveAsPrefabAsset(parent, Root + "/Generated/Parallax.prefab");
            AssetDatabase.SaveAssets();
            Debug.Log("Parallax preparat: 4 fulls de 12 × 4 tiles, cel i prefab. Arrossega Generated/Parallax a Level01.");
        }
        finally { Object.DestroyImmediate(parent); }
    }

    private static void CreateLayer(Transform parent, string name, int order, float depth, float y)
    {
        string path = Root + "/Textures/" + name + ".png";
        var importer = AssetImporter.GetAtPath(path) as TextureImporter;
        if (!importer) throw new FileNotFoundException("Falta " + path);
        importer.textureType = TextureImporterType.Sprite;
        importer.spriteImportMode = SpriteImportMode.Multiple;
        importer.spritePixelsPerUnit = TilePixels / 2f;
        importer.filterMode = FilterMode.Point;
        importer.mipmapEnabled = false;
        importer.textureCompression = TextureImporterCompression.Uncompressed;
        importer.maxTextureSize = 4096;
        importer.alphaIsTransparency = true;
        var settings = new TextureImporterSettings(); importer.ReadTextureSettings(settings);
        settings.spriteMeshType = SpriteMeshType.FullRect; importer.SetTextureSettings(settings);
        importer.SaveAndReimport();
        var texture = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        // Clouds té un píxel transparent menys a la vora dreta.
        // Conservem les 12 cel·les i compensem només l'últim pivot, sense estirar el dibuix.
        int columns = Mathf.CeilToInt(texture.width / (float)TilePixels), rows = texture.height / TilePixels;
        if (columns != 12 || texture.height != 724 || texture.width < 2171 || texture.width > 2172)
            throw new System.ArgumentException("S'esperen fulls de 2172 × 724 (Clouds: 2171 × 724).");
        var factory = new SpriteDataProviderFactories(); factory.Init();
        var provider = factory.GetSpriteEditorDataProviderFromObject(importer);
        provider.InitSpriteEditorDataProvider();
        var previous = provider.GetSpriteRects().ToDictionary(r => r.name);
        var rects = new SpriteRect[columns * rows];
        for (int row = 0; row < rows; row++)
            for (int col = 0; col < columns; col++)
            {
                string spriteName = name + "_" + col.ToString("D2") + "_" + row.ToString("D2");
                rects[row * columns + col] = new SpriteRect
                {
                    name = spriteName,
                    spriteID = previous.TryGetValue(spriteName, out var old) ? old.spriteID : GUID.Generate(),
                    rect = new Rect(col * TilePixels, row * TilePixels, Mathf.Min(TilePixels, texture.width - col * TilePixels), TilePixels),
                    alignment = SpriteAlignment.Custom,
                    pivot = new Vector2(TilePixels * .5f / Mathf.Min(TilePixels, texture.width - col * TilePixels), .5f)
                };
            }
        provider.SetSpriteRects(rects);
        var names = provider.GetDataProvider<ISpriteNameFileIdDataProvider>();
        names.SetNameFileIdPairs(rects.Select(r => new SpriteNameFileIdPair(r.name, r.spriteID)));
        provider.Apply(); importer.SaveAndReimport();
        var sprites = AssetDatabase.LoadAllAssetsAtPath(path).OfType<Sprite>().ToDictionary(s => s.name);
        var map = NewMap(parent, name, order, depth, columns, y);
        if (name == "Clouds") map.color = new Color(.83f, .95f, .91f, .55f);
        string folder = Root + "/Generated/" + name; Directory.CreateDirectory(folder);
        foreach (var rect in rects)
        {
            string tilePath = folder + "/" + rect.name + ".asset";
            var tile = AssetDatabase.LoadAssetAtPath<Tile>(tilePath);
            if (!tile) { tile = ScriptableObject.CreateInstance<Tile>(); AssetDatabase.CreateAsset(tile, tilePath); }
            tile.sprite = sprites[rect.name]; tile.colliderType = Tile.ColliderType.None;
            EditorUtility.SetDirty(tile);
            map.SetTile(new Vector3Int((int)rect.rect.x / TilePixels, (int)rect.rect.y / TilePixels, 0), tile);
        }
        // Retira només peces generades que ja no existeixen després d'un nou retall.
        foreach (var oldPath in Directory.GetFiles(folder, "*.asset"))
        {
            string oldName = Path.GetFileNameWithoutExtension(oldPath);
            if (oldName.StartsWith(name + "_") && !sprites.ContainsKey(oldName))
                AssetDatabase.DeleteAsset(oldPath.Replace('\\', '/'));
        }
        if (name == "Forest")
        {
            // Allarga el color de base sota la il·lustració: als forats del terreny
            // no ha d'aparèixer una franja de cel sota el bosc.
            var baseGO = new GameObject("ForestBase", typeof(Tilemap), typeof(TilemapRenderer));
            baseGO.transform.SetParent(map.transform, false);
            var baseMap = baseGO.GetComponent<Tilemap>();
            var baseRenderer = baseGO.GetComponent<TilemapRenderer>();
            baseRenderer.sharedMaterial = map.GetComponent<TilemapRenderer>().sharedMaterial;
            baseRenderer.sortingOrder = order - 1;
            baseMap.color = new Color32(40, 84, 88, 255);
            // El tile del cel és acolorit: fem servir una còpia amb sprite blanc.
            string whitePath = Root + "/Generated/White.png";
            if (!File.Exists(whitePath))
            {
                var white = new Texture2D(1, 1); white.SetPixel(0, 0, Color.white); white.Apply();
                File.WriteAllBytes(whitePath, white.EncodeToPNG()); Object.DestroyImmediate(white); AssetDatabase.ImportAsset(whitePath);
            }
            var wi = (TextureImporter)AssetImporter.GetAtPath(whitePath);
            wi.textureType = TextureImporterType.Sprite; wi.spriteImportMode = SpriteImportMode.Single;
            wi.spritePixelsPerUnit = .5f; wi.filterMode = FilterMode.Point; wi.mipmapEnabled = false; wi.SaveAndReimport();
            string basePath = Root + "/Generated/ForestBase.asset";
            var baseTile = AssetDatabase.LoadAssetAtPath<Tile>(basePath);
            if (!baseTile) { baseTile = ScriptableObject.CreateInstance<Tile>(); AssetDatabase.CreateAsset(baseTile, basePath); }
            baseTile.sprite = AssetDatabase.LoadAssetAtPath<Sprite>(whitePath); baseTile.colliderType = Tile.ColliderType.None;
            EditorUtility.SetDirty(baseTile);
            for (int x = 0; x < columns; x++) for (int row = -8; row < 1; row++) baseMap.SetTile(new Vector3Int(x, row, 0), baseTile);
        }
    }

    private static Tilemap NewMap(Transform parent, string name, int order, float depth, int columns, float y)
    {
        var layer = new GameObject(name, typeof(Grid), typeof(ParallaxTilemapLayer));
        layer.transform.SetParent(parent, false); layer.transform.localPosition = new Vector3(-12f, y, 0f);
        layer.GetComponent<Grid>().cellSize = new Vector3(2f, 2f, 0f);
        var go = new GameObject("Tiles", typeof(Tilemap), typeof(TilemapRenderer)); go.transform.SetParent(layer.transform, false);
        var map = go.GetComponent<Tilemap>(); var renderer = go.GetComponent<TilemapRenderer>();
        renderer.sortingOrder = order;
        renderer.sharedMaterial = AssetDatabase.LoadAssetAtPath<Material>(Root + "/Generated/ParallaxUnlit.mat");
        var data = new SerializedObject(layer.GetComponent<ParallaxTilemapLayer>());
        data.FindProperty("source").objectReferenceValue = map;
        data.FindProperty("blockWidthCells").intValue = columns;
        data.FindProperty("depth").floatValue = depth;
        data.ApplyModifiedPropertiesWithoutUndo();
        return map;
    }

    private static void CreateSky(Transform parent)
    {
        string materialPath = Root + "/Generated/ParallaxUnlit.mat";
        if (!AssetDatabase.LoadAssetAtPath<Material>(materialPath))
            AssetDatabase.CreateAsset(new Material(Shader.Find("Universal Render Pipeline/2D/Sprite-Unlit-Default")), materialPath);
        string path = Root + "/Generated/Sky.png";
        if (!File.Exists(path))
        {
            var texture = new Texture2D(1, 1); texture.SetPixel(0, 0, new Color32(194, 222, 220, 255)); texture.Apply();
            File.WriteAllBytes(path, texture.EncodeToPNG()); Object.DestroyImmediate(texture); AssetDatabase.ImportAsset(path);
        }
        var importer = (TextureImporter)AssetImporter.GetAtPath(path);
        importer.textureType = TextureImporterType.Sprite; importer.spriteImportMode = SpriteImportMode.Single;
        importer.spritePixelsPerUnit = .5f; importer.filterMode = FilterMode.Point; importer.mipmapEnabled = false;
        importer.textureCompression = TextureImporterCompression.Uncompressed; importer.SaveAndReimport();
        string tilePath = Root + "/Generated/Sky.asset";
        var tile = AssetDatabase.LoadAssetAtPath<Tile>(tilePath);
        if (!tile) { tile = ScriptableObject.CreateInstance<Tile>(); AssetDatabase.CreateAsset(tile, tilePath); }
        tile.sprite = AssetDatabase.LoadAssetAtPath<Sprite>(path); tile.colliderType = Tile.ColliderType.None; EditorUtility.SetDirty(tile);
        var map = NewMap(parent, "Sky", -100, 0f, 12, -5f);
        for (int x = 0; x < 12; x++) for (int y = 0; y < 12; y++) map.SetTile(new Vector3Int(x, y, 0), tile);
    }
}
