using UnityEngine;
using UnityEngine.InputSystem;
using TMPro;

public class MechanismPuzzle : MonoBehaviour
{
    public MechanismPlayer player;
    public Rigidbody box;
    public MechanismPlate plate;
    public MechanismGate gate;
    public TMP_Text statusText;
    private Vector3 boxStart;
    private Quaternion boxRotation;
    private bool won;

    void Start()
    {
        // Desa la posició i la rotació originals de la caixa per reiniciar el trencaclosques.
        boxStart = box.position;
        boxRotation = box.rotation;
        ShowInstructions();
    }

    void Update()
    {
        var keys = Keyboard.current;
        if ((keys != null && keys.rKey.wasPressedThisFrame) ||
            player.transform.position.y < -8f || box.position.y < -8f)
            ResetPuzzle();
    }

    public void Win()
    {
        if (won) return;
        won = true;
        statusText.text = "Tresor aconseguit! Prem R per tornar a començar.";
    }

    public void ResetPuzzle()
    {
        player.ResetPosition();
        // Atura el desplaçament i el gir de la caixa perquè no conservi l'impuls en reiniciar.
        box.linearVelocity = Vector3.zero;
        box.angularVelocity = Vector3.zero;
        box.position = boxStart;
        box.rotation = boxRotation;
        // Reinicia també els mecanismes perquè coincideixin amb la posició inicial dels objectes.
        plate.ResetPlate();
        gate.ResetGate();
        // Actualitza la informació física dels colliders amb els canvis de posició.
        Physics.SyncTransforms();
        won = false;
        ShowInstructions();
    }

    void ShowInstructions()
    {
        statusText.text = "Deixa la caixa sobre la placa i arriba al tresor.";
    }
}
