using UnityEngine;
using UnityEngine.InputSystem;

// Unity afegeix un Character Controller si l'objecte encara no en té.
[RequireComponent(typeof(CharacterController))]
public class MechanismPlayer : MonoBehaviour
{
    public float speed = 3f;
    public float pushSpeed = 2f;
    public float gravity = -20f;
    private CharacterController controller;
    private Vector3 startPosition;
    private float verticalSpeed;

    void Awake()
    {
        // Obtén el controlador del mateix objecte per moure'l respectant els colliders.
        controller = GetComponent<CharacterController>();
        // Desa la posició inicial per poder-hi tornar si el jugador cau o reinicia.
        startPosition = transform.position;
    }

    void Update()
    {
        Vector3 direction = Vector3.zero;
        var keys = Keyboard.current;
        if (keys != null)
        {
            if (keys.wKey.isPressed || keys.upArrowKey.isPressed) direction.z += 1;
            if (keys.sKey.isPressed || keys.downArrowKey.isPressed) direction.z -= 1;
            if (keys.dKey.isPressed || keys.rightArrowKey.isPressed) direction.x += 1;
            if (keys.aKey.isPressed || keys.leftArrowKey.isPressed) direction.x -= 1;
        }
        // Conserva la direcció però iguala la velocitat del moviment diagonal i recte.
        direction = direction.normalized;
        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
        // Acumula la caiguda: CharacterController.Move no aplica gravetat automàticament.
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
    }

    // Unity crida aquest mètode quan controller.Move troba un collider sòlid.
    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        // Busca el cos físic al qual pertany el collider amb què ha topat el jugador.
        Rigidbody body = hit.collider.attachedRigidbody;
        // Només empeny cossos moguts per la física i marcats amb el tag Pushable.
        if (body == null || body.isKinematic || !body.CompareTag("Pushable")) return;
        // Si el contacte és amb la part superior de la caixa, evita empènyer-la en trepitjar-la.
        if (hit.normal.y > 0.5f) return;
        // Elimina el component vertical del moviment per empènyer només sobre el pla del terra.
        Vector3 direction = Vector3.ProjectOnPlane(hit.moveDirection, Vector3.up).normalized;
        // Empeny la caixa horitzontalment i conserva la velocitat vertical perquè pugui continuar
        // caient.
        body.linearVelocity = new Vector3(direction.x * pushSpeed,
            body.linearVelocity.y, direction.z * pushSpeed);
    }

    public void ResetPosition()
    {
        // Desactiva temporalment el controlador per recol·locar el personatge directament.
        controller.enabled = false;
        transform.position = startPosition;
        controller.enabled = true;
        verticalSpeed = 0f;
    }
}
