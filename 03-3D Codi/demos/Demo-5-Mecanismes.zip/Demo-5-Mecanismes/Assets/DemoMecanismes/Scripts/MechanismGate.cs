using UnityEngine;

// Aquest script necessita un Rigidbody al mateix objecte.
[RequireComponent(typeof(Rigidbody))]
public class MechanismGate : MonoBehaviour
{
    public float openHeight = 3f;
    public float speed = 5f;
    private Rigidbody body;
    private Vector3 closedPosition;
    private bool open;

    void Awake()
    {
        // Obtén el cos físic del mateix objecte per controlar-ne el moviment.
        body = GetComponent<Rigidbody>();
        closedPosition = body.position;
    }

    public void SetOpen(bool value)
    {
        // Rep l'estat de la placa; FixedUpdate farà obrir o tancar la porta.
        open = value;
    }

    // Unity executa aquest mètode a intervals fixos per actualitzar la física.
    void FixedUpdate()
    {
        // Tria la posició oberta o tancada segons si la placa està premuda.
        Vector3 target = closedPosition + (open ? Vector3.up * openHeight : Vector3.zero);
        body.MovePosition(Vector3.MoveTowards(body.position, target, speed * Time.fixedDeltaTime));
    }

    public void ResetGate()
    {
        open = false;
        body.position = closedPosition;
    }
}
