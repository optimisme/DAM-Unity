using UnityEngine;
using UnityEngine.Events;
using System.Collections.Generic;

public class MechanismPlate : MonoBehaviour
{
    public Renderer plateRenderer;
    public Color pressedColor = Color.green;
    // Esdeveniment connectable a l'Inspector: envia true en prémer la placa i false en alliberar-la.
    public UnityEvent<bool> onPressedChanged = new UnityEvent<bool>();
    // Desa els colliders sobre la placa sense duplicats; un de sol ja la manté premuda.
    private readonly HashSet<Collider> occupants = new HashSet<Collider>();
    private Material ownMaterial;
    private Color originalColor;
    private bool pressed;

    void Awake()
    {
        // Crea una còpia del material per canviar només el color d'aquesta placa.
        ownMaterial = plateRenderer.material;
        originalColor = ownMaterial.GetColor("_BaseColor");
    }

    bool IsWeight(Collider other)
    {
        // Accepta el jugador o una caixa amb Rigidbody i tag Pushable com a pes.
        return other.CompareTag("Player") ||
            (other.attachedRigidbody != null && other.attachedRigidbody.CompareTag("Pushable"));
    }

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        if (IsWeight(other)) occupants.Add(other);
        UpdateState();
    }

    // Unity avisa quan un collider surt del trigger.
    void OnTriggerExit(Collider other)
    {
        occupants.Remove(other);
        UpdateState();
    }

    void Update()
    {
        // Elimina els objectes desactivats o destruïts: poden no haver avisat amb OnTriggerExit.
        occupants.RemoveWhere(c => c == null || !c.enabled || !c.gameObject.activeInHierarchy);
        UpdateState();
    }

    void UpdateState()
    {
        // La placa està premuda mentre quedi almenys un collider vàlid dins del trigger.
        bool next = occupants.Count > 0;
        // Envia l'avís només quan canvia l'estat, no a cada frame.
        if (next == pressed) return;
        pressed = next;
        ownMaterial.SetColor("_BaseColor", pressed ? pressedColor : originalColor);
        // Avisa els mètodes connectats a l'Inspector, com MechanismGate.SetOpen.
        onPressedChanged.Invoke(pressed);
    }

    public void ResetPlate()
    {
        occupants.Clear();
        pressed = false;
        ownMaterial.SetColor("_BaseColor", originalColor);
        onPressedChanged.Invoke(false);
    }

    void OnDestroy()
    {
        // Allibera la còpia del material creada per aquest script.
        if (ownMaterial != null) Destroy(ownMaterial);
    }
}
