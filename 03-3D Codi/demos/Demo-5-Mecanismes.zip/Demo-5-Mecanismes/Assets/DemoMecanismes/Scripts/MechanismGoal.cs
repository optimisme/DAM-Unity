using UnityEngine;

public class MechanismGoal : MonoBehaviour
{
    public MechanismPuzzle puzzle;

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        // Només el jugador pot completar el repte entrant a la zona del tresor.
        if (other.CompareTag("Player")) puzzle.Win();
    }
}
