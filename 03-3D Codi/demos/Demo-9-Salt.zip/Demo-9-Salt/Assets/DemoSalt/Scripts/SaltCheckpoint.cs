using UnityEngine;

public class SaltCheckpoint : MonoBehaviour
{
    public SaltGame game;
    public Transform spawnPoint;
    public Renderer visual;
    Material material;

    void Awake() => material = visual.material;

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        // Activa el punt de control només per al jugador d'aquesta partida i abans de guanyar.
        if (other.GetComponent<SaltPlayer>() == game.player && !game.Won)
            game.ActivateCheckpoint(this);
    }

    public void SetActiveColor(bool active)
    {
        material.SetColor("_BaseColor", active ? new Color(0.2f, 0.9f, 0.4f) : new Color(0.2f, 0.6f, 1));
    }

    void OnDestroy()
    {
        // Allibera la còpia del material perquè no quedi ocupant memòria.
        if (material != null) Destroy(material);
    }
}
