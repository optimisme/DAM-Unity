using UnityEngine;
using UnityEngine.InputSystem;

// Unity afegeix un Character Controller si l'objecte encara no en té.
[RequireComponent(typeof(CharacterController))]
public class SaltPlayer : MonoBehaviour
{
    public SaltGame game;
    public float speed = 4;
    public float jumpSpeed = 8;
    public float gravity = 20;
    public float releaseGravity = 35;
    // Marge per poder saltar just després de sortir d'una vora.
    public float coyoteTime = 0.12f;
    // Temps que recordem una pulsació de salt feta una mica abans de tocar terra.
    public float jumpBuffer = 0.12f;
    CharacterController controller;
    float verticalSpeed;
    // Un instant molt antic indica que encara no hi ha un contacte o una pulsació aprofitables.
    float lastGrounded = float.NegativeInfinity;
    float lastJumpPressed = float.NegativeInfinity;

    void Awake() => controller = GetComponent<CharacterController>();

    void Update()
    {
        if (game.Won) return;
        var keyboard = Keyboard.current;
        Vector2 input = Vector2.zero;
        bool jumpHeld = false;
        if (keyboard != null)
        {
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y++;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y--;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x--;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x++;
            jumpHeld = keyboard.spaceKey.isPressed;
            // Desa quan s'ha premut espai per poder aprofitar la pulsació en aterrar.
            if (keyboard.spaceKey.wasPressedThisFrame) lastJumpPressed = Time.time;
        }
        // Limita la intensitat del moviment per evitar anar més ràpid en diagonal.
        input = Vector2.ClampMagnitude(input, 1);
        // Accepta el contacte amb el terra només si no està pujant, per no renovar el marge durant el
        // salt.
        bool grounded = controller.isGrounded && verticalSpeed <= 0;
        if (grounded)
        {
            lastGrounded = Time.time;
            verticalSpeed = -2;
        }
        // Salta si la pulsació és recent i encara és dins del marge des de l'últim contacte amb el
        // terra.
        if (Time.time - lastJumpPressed <= jumpBuffer && Time.time - lastGrounded <= coyoteTime)
        {
            // Inicia el salt donant velocitat cap amunt.
            verticalSpeed = jumpSpeed;
            // Consumeix la pulsació i el contacte per evitar un segon salt amb les mateixes dades.
            lastJumpPressed = lastGrounded = float.NegativeInfinity;
        }
        // Si deixa anar espai mentre puja, augmenta la gravetat per fer un salt més curt.
        float acceleration = verticalSpeed > 0 && !jumpHeld ? releaseGravity : gravity;
        verticalSpeed -= acceleration * Time.deltaTime;
        Vector3 movement = new Vector3(input.x * speed, verticalSpeed, input.y * speed);
        // Mou el jugador i desa si el controlador ha tocat terra, sostre o laterals.
        CollisionFlags flags = controller.Move(movement * Time.deltaTime);
        // Comprova el senyal de contacte amb el sostre i atura la pujada si hi ha topat.
        if ((flags & CollisionFlags.Above) != 0 && verticalSpeed > 0) verticalSpeed = 0;
        if (input.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.LookRotation(new Vector3(input.x, 0, input.y));
        // Avisa el gestor quan el jugador cau per sota del nivell.
        if (transform.position.y < -5) game.Fall();
    }

    public void Teleport(Vector3 position)
    {
        // Desactiva temporalment el controlador per recol·locar el personatge directament.
        controller.enabled = false;
        transform.SetPositionAndRotation(position, Quaternion.identity);
        controller.enabled = true;
        verticalSpeed = 0;
        // Descarta els marges de salt anteriors perquè no s'apliquin després de reaparèixer.
        lastGrounded = lastJumpPressed = float.NegativeInfinity;
        // Actualitza la informació física dels colliders amb els canvis de posició.
        Physics.SyncTransforms();
    }
}
