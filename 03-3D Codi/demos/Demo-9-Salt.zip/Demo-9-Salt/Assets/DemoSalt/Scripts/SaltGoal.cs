using UnityEngine;

public class SaltGoal : MonoBehaviour
{
    public SaltGame game;

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        // Només el jugador de la partida pot activar l'arribada a la meta.
        if (other.GetComponent<SaltPlayer>() == game.player) game.Finish();
    }
}
