using UnityEngine;

public class DioramaPickup : MonoBehaviour
{
    public DioramaProgress progress;
    public bool isTreasure;
    private bool collected;

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || collected) return;
        // El tresor comprova la victòria; les altres esferes incrementen el recompte.
        if (isTreasure)
        {
            progress.ReachTreasure();
            return;
        }
        collected = true;
        // Avisa el gestor del nivell que s'ha recollit una esfera.
        progress.Collect();
        // Amaga l'objecte i desactiva els seus components després de recollir-lo.
        gameObject.SetActive(false);
    }
}
