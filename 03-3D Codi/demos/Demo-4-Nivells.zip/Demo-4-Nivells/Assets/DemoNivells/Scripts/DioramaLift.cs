using UnityEngine;

// Mou primer l'ascensor perquè el jugador pugui llegir-ne el desplaçament d'aquest frame.
[DefaultExecutionOrder(-100)]
public class DioramaLift : MonoBehaviour
{
    public Transform bottom;
    public Transform top;
    public float speed = 1.2f;
    public float waitTime = 2f;
    // DioramaPlayer pot llegir aquest desplaçament per viatjar amb l'ascensor; només aquest script el
    // modifica.
    public Vector3 Delta { get; private set; }
    private bool goingUp = true;
    private float remainingWait;

    void Start()
    {
        transform.position = bottom.position;
        remainingWait = waitTime;
    }

    void Update()
    {
        Vector3 previous = transform.position;
        // Descompta l'espera de cada parada abans de reprendre el recorregut.
        if (remainingWait > 0f) remainingWait -= Time.deltaTime;
        else
        {
            // Tria el punt superior o inferior segons el sentit actual del trajecte.
            Vector3 target = goingUp ? top.position : bottom.position;
            transform.position = Vector3.MoveTowards(previous, target, speed * Time.deltaTime);
            if (Vector3.Distance(transform.position, target) < 0.001f)
            {
                // En arribar, inverteix el sentit i prepara una nova espera.
                goingUp = !goingUp;
                remainingWait = waitTime;
            }
        }
        // Desa quant s'ha mogut aquest frame; durant l'espera el desplaçament és zero.
        Delta = transform.position - previous;
    }
}
