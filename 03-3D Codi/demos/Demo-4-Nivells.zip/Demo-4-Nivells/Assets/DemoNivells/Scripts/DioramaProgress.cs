using UnityEngine;
using TMPro;

public class DioramaProgress : MonoBehaviour
{
    public int total = 3;
    public Transform door;
    public TMP_Text statusText;
    public float openHeight = 2.5f;
    private int collected;
    private Vector3 closedPosition;
    private bool won;
    // Propietat calculada: la porta es pot obrir quan el recompte arriba al total.
    public bool IsOpen => collected >= total;

    void Start()
    {
        // Desa la posició tancada per calcular l'altura final de la porta.
        closedPosition = door.position;
        UpdateText();
    }

    void Update()
    {
        if (IsOpen)
            door.position = Vector3.MoveTowards(door.position,
                closedPosition + Vector3.up * openHeight, 2f * Time.deltaTime);
    }

    public void Collect()
    {
        // DioramaPickup avisa d'una nova esfera; actualitza el recompte i el text.
        collected++;
        UpdateText();
    }

    public void ReachTreasure()
    {
        // Només completa el repte si la porta està desbloquejada i encara no s'ha guanyat.
        if (!IsOpen || won) return;
        won = true;
        UpdateText();
    }

    void UpdateText()
    {
        statusText.text = won ? "Tresor aconseguit!" :
            $"Esferes: {collected}/{total}" + (IsOpen ? "  —  Porta oberta!" : "");
    }
}
