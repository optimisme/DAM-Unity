using UnityEngine;
using UnityEngine.InputSystem;

// Unity afegeix un Character Controller si l'objecte encara no en té.
[RequireComponent(typeof(CharacterController))]
public class DioramaPlayer : MonoBehaviour
{
    public Transform viewCamera;
    public float speed = 3f;
    public float gravity = -20f;
    private CharacterController controller;
    private DioramaLift support;
    private Vector3 startPosition;
    private float verticalSpeed;

    void Awake()
    {
        // Obtén el controlador del mateix objecte per moure'l respectant els colliders.
        controller = GetComponent<CharacterController>();
        // Desa la posició inicial per poder-hi tornar si el jugador cau o reinicia.
        startPosition = transform.position;
    }

    void Update()
    {
        // Aplica el desplaçament de l'ascensor amb què el jugador estava en contacte.
        if (support != null) controller.Move(support.Delta);
        // Esborra el suport anterior; els nous contactes del controlador el tornaran a detectar.
        support = null;

        Vector2 input = Vector2.zero;
        var keys = Keyboard.current;
        if (keys != null)
        {
            if (keys.wKey.isPressed || keys.upArrowKey.isPressed) input.y += 1;
            if (keys.sKey.isPressed || keys.downArrowKey.isPressed) input.y -= 1;
            if (keys.dKey.isPressed || keys.rightArrowKey.isPressed) input.x += 1;
            if (keys.aKey.isPressed || keys.leftArrowKey.isPressed) input.x -= 1;
        }
        // Limita la intensitat del moviment per evitar anar més ràpid en diagonal.
        input = Vector2.ClampMagnitude(input, 1f);
        // Projecta la direcció de la càmera sobre el terra perquè mirar cap avall no faci baixar el
        // jugador.
        Vector3 forward = Vector3.ProjectOnPlane(viewCamera.forward, Vector3.up).normalized;
        Vector3 right = Vector3.ProjectOnPlane(viewCamera.right, Vector3.up).normalized;
        // Converteix les tecles en moviment relatiu a la vista de la càmera.
        Vector3 direction = forward * input.y + right * input.x;

        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
        // Acumula la caiguda: CharacterController.Move no aplica gravetat automàticament.
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
        if (direction.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(direction);

        // Si cau fora del nivell, torna a l'inici i conserva les esferes recollides.
        if (transform.position.y < -8f)
        {
            // Desactiva temporalment el controlador per recol·locar el personatge directament.
            controller.enabled = false;
            transform.position = startPosition;
            controller.enabled = true;
            verticalSpeed = 0f;
            // Esborra el suport anterior; els nous contactes del controlador el tornaran a detectar.
            support = null;
        }
    }

    // Unity crida aquest mètode quan controller.Move troba un collider sòlid.
    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        // Una normal que apunta prou cap amunt indica un suport sota els peus, no una paret lateral.
        if (hit.normal.y > 0.5f)
            support = hit.collider.GetComponent<DioramaLift>();
    }
}
