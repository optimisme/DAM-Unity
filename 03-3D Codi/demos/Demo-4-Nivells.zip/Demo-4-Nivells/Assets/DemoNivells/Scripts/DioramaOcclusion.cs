using UnityEngine;
using System.Collections.Generic;

// Comprova què tapa el jugador després que DioramaCamera hagi actualitzat la vista.
[DefaultExecutionOrder(200)]
public class DioramaOcclusion : MonoBehaviour
{
    public Transform player;
    public LayerMask wallsMask;
    private DioramaWall[] walls;
    // Conjunt de parets que tapen el jugador; HashSet evita desar la mateixa paret dues vegades.
    private readonly HashSet<DioramaWall> obstructing = new HashSet<DioramaWall>();

    void Start()
    {
        // Busca les parets actives amb DioramaWall per poder actualitzar-ne la transparència.
        walls = FindObjectsByType<DioramaWall>();
    }

    void LateUpdate()
    {
        // Refà la llista d'obstacles a cada frame, perquè la càmera i el jugador es poden moure.
        obstructing.Clear();
        // Busca les parets entre la càmera i el jugador per fer-les transparents.
        Vector3 origin = transform.position;
        Vector3 toPlayer = player.position - origin;
        float distance = toPlayer.magnitude;
        Vector3 direction = distance > 0.001f ? toPlayer / distance : transform.forward;
        // Comprova un recorregut amb gruix fins al jugador; wallsMask limita les capes i s'ignoren els
        // triggers.
        RaycastHit[] hits = Physics.SphereCastAll(origin, 0.25f, direction,
            distance, wallsMask, QueryTriggerInteraction.Ignore);
        foreach (RaycastHit hit in hits)
        {
            DioramaWall wall = hit.collider.GetComponent<DioramaWall>();
            if (wall != null) obstructing.Add(wall);
        }
        // Actualitza totes les parets, incloses les que han deixat de tapar el jugador.
        foreach (DioramaWall wall in walls)
            if (wall != null) wall.SetObstructing(obstructing.Contains(wall));
    }
}
