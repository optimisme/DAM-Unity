using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class DioramaWall : MonoBehaviour
{
    [Range(0f, 1f)] public float hiddenAlpha = 0.25f;
    public float fadeSpeed = 3f;
    private Material ownMaterial;
    private Color originalColor;

    void Awake()
    {
        // Crea un material propi per a aquesta paret: canviar-ne la transparència no afecta les altres.
        ownMaterial = GetComponent<Renderer>().material;
        originalColor = ownMaterial.GetColor("_BaseColor");
    }

    public void SetObstructing(bool obstructing)
    {
        Color color = ownMaterial.GetColor("_BaseColor");
        // Si la paret tapa el jugador, redueix-ne l'opacitat; si no, recupera l'original.
        float target = obstructing ? hiddenAlpha : originalColor.a;
        // Canvia l'alpha gradualment perquè la transparència no aparegui de cop.
        color.a = Mathf.MoveTowards(color.a, target, fadeSpeed * Time.deltaTime);
        ownMaterial.SetColor("_BaseColor", color);
    }

    void OnDestroy()
    {
        // Allibera la còpia del material creada per aquest script.
        if (ownMaterial != null) Destroy(ownMaterial);
    }
}
