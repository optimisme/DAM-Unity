using UnityEngine;

public class CylinderColor : MonoBehaviour
{
    public Color contactColor = Color.red;

    private Material objectMaterial;
    private Color originalColor;

    void Awake()
    {
        objectMaterial = GetComponent<Renderer>().material;
        originalColor = objectMaterial.GetColor("_BaseColor");
    }

    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        Debug.Log("El jugador ha entrat al trigger de: " + gameObject.name);

        objectMaterial.SetColor("_BaseColor", contactColor);

    }

    void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Player"))
            return;

        objectMaterial.SetColor("_BaseColor", originalColor);
    }
}
