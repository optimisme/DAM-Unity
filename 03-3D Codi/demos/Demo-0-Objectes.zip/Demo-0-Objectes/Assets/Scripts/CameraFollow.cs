using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;

    public float distance = 5f;
    public float height = 5f;

    void LateUpdate()
    {
        Vector3 offset = new Vector3(0, height, -distance);

        transform.position = target.position + offset;

        transform.LookAt(target);
    }
}
