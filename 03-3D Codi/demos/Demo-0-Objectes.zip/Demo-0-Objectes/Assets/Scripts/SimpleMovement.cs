using UnityEngine;
using UnityEngine.InputSystem;

public class SimpleMovement : MonoBehaviour
{
    public float speed = 5f;

    private CharacterController controller;
    private Color defaultColor;

    void Start()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        if (Keyboard.current == null)
            return;

        Vector3 movement = Vector3.zero;

        if (Keyboard.current.upArrowKey.isPressed)
            movement += Vector3.forward;

        if (Keyboard.current.downArrowKey.isPressed)
            movement += Vector3.back;

        if (Keyboard.current.leftArrowKey.isPressed)
            movement += Vector3.left;

        if (Keyboard.current.rightArrowKey.isPressed)
            movement += Vector3.right;

        controller.Move(
            movement.normalized * speed * Time.deltaTime
        );
    }

    void OnTriggerEnter(Collider other)
    {
        Debug.Log("Entrada al trigger: " + other.gameObject.name);
        Debug.Log("Tag de l'objecte: " + other.gameObject.tag);

        if (other.CompareTag("ColorHit"))
        {
            Renderer objectRenderer = other.GetComponent<Renderer>();
            Material objectMaterial = objectRenderer.material;
            
            defaultColor = objectMaterial.GetColor("_BaseColor");
            objectMaterial.SetColor("_BaseColor", Color.red);
        }
    }

    void OnTriggerExit(Collider other)
    {
        Debug.Log("Sortida del trigger: " + other.gameObject.name);
        Debug.Log("Tag de l'objecte: " + other.gameObject.tag);

        if (other.CompareTag("ColorHit"))
        {
            Renderer objectRenderer = other.GetComponent<Renderer>();
            Material objectMaterial = objectRenderer.material;

            objectMaterial.SetColor("_BaseColor", defaultColor);
        }
    }
}
