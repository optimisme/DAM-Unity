using UnityEngine;

public class PalancaTreasure : MonoBehaviour
{
    public PalancaSwitch lever;
    private bool collected;

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        if (collected || !other.CompareTag("Player")) return;
        collected = true;
        // El tresor avisa la palanca perquè mostri el missatge de repte completat.
        lever.Win();
        // Amaga l'objecte i desactiva els seus components després de recollir-lo.
        gameObject.SetActive(false);
    }
}
