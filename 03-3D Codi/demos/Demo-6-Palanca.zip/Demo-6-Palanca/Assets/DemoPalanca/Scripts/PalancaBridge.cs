using UnityEngine;
using System.Collections.Generic;

public class PalancaBridge : MonoBehaviour
{
    public Animator animator;
    public Collider deckCollider;
    public Collider[] barriers;
    // Guarda els colliders del jugador que ocupen el pont, sense duplicats.
    private readonly HashSet<Collider> occupants = new HashSet<Collider>();
    private bool requestedOpen;
    private Collider zone;

    public bool IsOpen { get; private set; }
    public bool IsMoving { get; private set; }
    // TryToggle consulta si hi ha algú al pont; la palanca també ho mostra al panell.
    public bool IsOccupied => occupants.Count > 0;

    void Awake()
    {
        zone = GetComponent<Collider>();
    }

    void Update()
    {
        // Neteja contactes antics, inclosos objectes desactivats o que ja no són dins de la zona.
        occupants.RemoveWhere(c => c == null || !c.enabled || !c.gameObject.activeInHierarchy
            || !zone.bounds.Intersects(c.bounds));
        // Llegeix l'estat de la primera capa de l'Animator per saber en quin punt és l'animació.
        AnimatorStateInfo state = animator.GetCurrentAnimatorStateInfo(0);
        bool transitioning = animator.IsInTransition(0);
        // Considera el pont obert al pas quan és abaixat i no està en una transició.
        IsOpen = state.IsName("Base Layer.Lowered") && !transitioning;
        bool settled = state.IsName(requestedOpen ? "Base Layer.Lowered" : "Base Layer.Raised");
        IsMoving = transitioning || !settled;
        // Permet trepitjar el tauler només quan està abaixat i aturat.
        deckCollider.enabled = IsOpen && !IsMoving;
        // Bloqueja els accessos mentre no es pot passar pel tauler.
        foreach (Collider barrier in barriers) barrier.enabled = !deckCollider.enabled;
    }

    public bool TryToggle()
    {
        // Rebutja l'acció si el pont encara es mou o hi ha un jugador a sobre.
        if (IsMoving || IsOccupied) return false;
        // Alterna entre demanar que el pont baixi i que pugi.
        requestedOpen = !requestedOpen;
        IsMoving = true;
        deckCollider.enabled = false;
        foreach (Collider barrier in barriers) barrier.enabled = true;
        // Canvia el paràmetre de l'Animator que activa les transicions del pont.
        animator.SetBool("isOpen", requestedOpen);
        return true;
    }

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) occupants.Add(other);
    }

    // Unity avisa quan un collider surt del trigger.
    void OnTriggerExit(Collider other)
    {
        occupants.Remove(other);
    }
}
