using UnityEngine;
using UnityEngine.InputSystem;

// Unity afegeix un Character Controller si l'objecte encara no en té.
[RequireComponent(typeof(CharacterController))]
public class PalancaPlayer : MonoBehaviour
{
    public PalancaSwitch lever;
    public float speed = 3f;
    public float gravity = -20f;
    private CharacterController controller;
    private Vector2 moveInput;
    private float verticalSpeed;
    private Vector3 startPosition;

    void Awake()
    {
        // Obtén el controlador del mateix objecte per moure'l respectant els colliders.
        controller = GetComponent<CharacterController>();
        // Desa la posició inicial per poder-hi tornar si el jugador cau o reinicia.
        startPosition = transform.position;
    }

    // Player Input crida aquest mètode quan canvia l'acció Move configurada amb Send Messages.
    public void OnMove(InputValue value)
    {
        // Desa els dos eixos d'entrada; Update els convertirà en moviment sobre X i Z.
        moveInput = value.Get<Vector2>();
    }

    // Player Input envia aquí l'acció Interact; la palanca comprovarà si és prou a prop.
    public void OnInteract(InputValue value)
    {
        // Intenta activar la palanca en prémer el botó, no quan es deixa anar.
        if (value.isPressed) lever.TryUse();
    }

    void Update()
    {
        // Limita l'entrada per mantenir la mateixa velocitat en diagonal.
        Vector2 input = Vector2.ClampMagnitude(moveInput, 1f);
        Vector3 direction = new Vector3(input.x, 0f, input.y);
        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -2f;
        // Acumula la caiguda: CharacterController.Move no aplica gravetat automàticament.
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((direction * speed + Vector3.up * verticalSpeed) * Time.deltaTime);
        if (transform.position.y < -6f)
        {
            // Desactiva temporalment el controlador per recol·locar el personatge directament.
            controller.enabled = false;
            transform.position = startPosition;
            controller.enabled = true;
            verticalSpeed = 0f;
        }
    }
}
