using UnityEngine;
using TMPro;

public class PalancaSwitch : MonoBehaviour
{
    public Transform player;
    public PalancaBridge bridge;
    public Renderer handleRenderer;
    public TMP_Text statusText;
    public float interactionDistance = 2.5f;
    private Material ownMaterial;
    private bool won;

    void Awake()
    {
        ownMaterial = handleRenderer.material;
    }

    public void TryUse()
    {
        // La palanca només respon si el jugador és dins de la distància d'interacció.
        if (Vector3.Distance(player.position, transform.position) > interactionDistance) return;
        bridge.TryToggle();
    }

    public void Win()
    {
        won = true;
    }

    void Update()
    {
        // Mostra l'estat del pont amb el color de la palanca i el missatge del panell.
        ownMaterial.SetColor("_BaseColor", bridge.IsOpen ? Color.green : new Color(1f, 0.55f, 0.15f));
        if (won) statusText.text = "Repte completat!";
        else if (bridge.IsMoving) statusText.text = "Espera que el pont acabi de moure's.";
        else if (bridge.IsOccupied) statusText.text = "Pont ocupat: no es pot aixecar.";
        else if (Vector3.Distance(player.position, transform.position) <= interactionDistance)
            statusText.text = bridge.IsOpen ? "E: aixecar el pont" : "E: abaixar el pont";
        else statusText.text = "Acosta't a la palanca i prem E.";
    }

    void OnDestroy()
    {
        // Allibera la còpia del material creada per aquest script.
        if (ownMaterial != null) Destroy(ownMaterial);
    }
}
