// Només s'executa a l'Editor. No forma part del joc ni dels shaders exportats.
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DAM.Demos.Editor
{
    [InitializeOnLoad]
    internal static class DAMDemoStartup
    {
        private const string Marker = "Library/DAMDemoStartup.done";

        static DAMDemoStartup()
        {
            if (!Application.isBatchMode && !File.Exists(Marker))
                EditorApplication.update += OnFirstOpen;
        }

        private static void OnFirstOpen()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating ||
                EditorApplication.isPlayingOrWillChangePlaymode)
                return;

            EditorApplication.update -= OnFirstOpen;
            // Una escena que l'alumne ja ha obert o modificat té prioritat.
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var scene = SceneManager.GetSceneAt(i);
                if (scene.isDirty || !string.IsNullOrEmpty(scene.path))
                {
                    MarkOpened();
                    return;
                }
            }

            if (OpenDemo())
                MarkOpened();
        }

        [MenuItem("Demo/Obrir escena principal")]
        private static void OpenFromMenu()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;
            if (OpenDemo())
                MarkOpened();
        }

        private static bool OpenDemo()
        {
            foreach (var scene in EditorBuildSettings.scenes)
            {
                if (!scene.enabled || !File.Exists(scene.path))
                    continue;
                EditorSceneManager.OpenScene(scene.path, OpenSceneMode.Single);
                EditorApplication.delayCall += FrameDemo;
                Debug.Log("Demo preparada: " + scene.path);
                return true;
            }
            Debug.LogWarning("No hi ha cap escena de demo disponible a Build Settings.");
            return false;
        }

        private static void FrameDemo()
        {
            Bounds bounds = default;
            bool found = false;
            foreach (var renderer in UnityEngine.Object.FindObjectsByType<MeshRenderer>(FindObjectsSortMode.None))
            {
                if (!renderer.enabled || renderer.GetComponentInParent<Canvas>() != null)
                    continue;
                if (!found) bounds = renderer.bounds;
                else bounds.Encapsulate(renderer.bounds);
                found = true;
            }
            if (!found) return;
            var view = EditorWindow.GetWindow<SceneView>();
            if (Camera.main != null) view.rotation = Camera.main.transform.rotation;
            view.Frame(bounds, true);
            view.Repaint();
        }

        private static void MarkOpened()
        {
            Directory.CreateDirectory("Library");
            File.WriteAllText(Marker, "La demo ja s'ha obert. Les obertures següents respecten les escenes de l'alumne.\n");
        }
    }
}
