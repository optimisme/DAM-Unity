using UnityEngine;
[RequireComponent(typeof(Light))]
public class ProximityLight : MonoBehaviour
{
    public Transform player;
    public float activationDistance = 3f;

    private Light pointLight;

    void Awake()
    {
        pointLight = GetComponent<Light>();
        pointLight.enabled = false;
    }

    void LateUpdate()
    {
        float distance = Vector3.Distance(player.position, transform.position);

        // Enable the light only while the player is nearby.
        pointLight.enabled = distance <= activationDistance;
    }
}

