using UnityEngine;
[DefaultExecutionOrder(-100)]
public class ProximityPlatform : MonoBehaviour
{
    public Transform player;
    public Transform[] pathPoints;

    public float activationDistance = 4f;
    public float speed = 1.5f;
    public Color inactiveColor = Color.gray;
    public Color activeColor = Color.green;

    public Vector3 FrameMovement { get; private set; }

    private int targetIndex = 1;
    private int direction = 1;
    private Renderer platformRenderer;
    private MaterialPropertyBlock colorProperties;
    private bool isActive;

    void Start()
    {
        platformRenderer = GetComponent<Renderer>();
        colorProperties = new MaterialPropertyBlock();
        SetActivationColor(false);

        if (player == null || pathPoints == null || pathPoints.Length < 2)
        {
            Debug.LogError("Assigna Player i almenys dos Path Points a Platform.", this);
            enabled = false;
            return;
        }

        foreach (Transform point in pathPoints)
        {
            if (point == null)
            {
                Debug.LogError("Hi ha un Path Point sense assignar a Platform.", this);
                enabled = false;
                return;
            }
        }

        transform.position = pathPoints[0].position;
        Physics.SyncTransforms();
    }

    void Update()
    {
        FrameMovement = Vector3.zero;

        float distance = Vector3.Distance(player.position, transform.position);
        bool playerIsNear = distance <= activationDistance;

        if (playerIsNear != isActive)
            SetActivationColor(playerIsNear);

        if (!playerIsNear)
            return;

        Vector3 previousPosition = transform.position;
        Vector3 targetPosition = pathPoints[targetIndex].position;

        transform.position = Vector3.MoveTowards(
            transform.position,
            targetPosition,
            speed * Time.deltaTime
        );

        FrameMovement = transform.position - previousPosition;
        Physics.SyncTransforms();

        if (transform.position == targetPosition)
        {
            // Reverse at either end; otherwise continue to the next point.
            if (targetIndex == pathPoints.Length - 1)
                direction = -1;
            else if (targetIndex == 0)
                direction = 1;

            targetIndex += direction;
        }
    }

    void SetActivationColor(bool active)
    {
        isActive = active;

        if (platformRenderer == null)
            return;

        // Change only this renderer, without changing the shared material.
        platformRenderer.GetPropertyBlock(colorProperties);
        Color color = active ? activeColor : inactiveColor;
        colorProperties.SetColor("_BaseColor", color); // URP/Lit
        colorProperties.SetColor("_Color", color);     // Built-In/Standard
        platformRenderer.SetPropertyBlock(colorProperties);
    }
}


