using UnityEngine;
using UnityEngine.InputSystem;
[RequireComponent(typeof(CharacterController))]
public class PlayerMovement : MonoBehaviour
{
    public float speed = 4f;
    public float gravity = -20f;

    private CharacterController controller;
    private ProximityPlatform platform;
    private float verticalSpeed;

    void Awake()
    {
        controller = GetComponent<CharacterController>();
    }

    void Update()
    {
        Vector3 movement = Vector3.zero;
        Keyboard keyboard = Keyboard.current;

        if (keyboard != null)
        {
            if (keyboard.upArrowKey.isPressed)
                movement += Vector3.forward;

            if (keyboard.downArrowKey.isPressed)
                movement += Vector3.back;

            if (keyboard.leftArrowKey.isPressed)
                movement += Vector3.left;

            if (keyboard.rightArrowKey.isPressed)
                movement += Vector3.right;
        }

        // Keep the player in contact with the ground.
        if (controller.isGrounded && verticalSpeed < 0f)
            verticalSpeed = -2f;

        verticalSpeed += gravity * Time.deltaTime;

        Vector3 displacement = movement.normalized * speed * Time.deltaTime;
        displacement.y = verticalSpeed * Time.deltaTime;

        // Add the movement of the platform supporting the player.
        if (platform != null)
            displacement += platform.FrameMovement;

        // The collision callback finds the support again during Move.
        platform = null;
        controller.Move(displacement);
    }

    void OnControllerColliderHit(ControllerColliderHit hit)
    {
        // Only contacts under the player can provide support.
        if (hit.normal.y > 0.5f)
        {
            ProximityPlatform support = hit.collider.GetComponent<ProximityPlatform>();

            if (support != null)
                platform = support;
        }
    }
}

