# Demo-2-Plataformes

Projecte independent per a Unity 6.6 (6000.6.3f1), amb URP i Input System.

1. Descomprimeix tot el ZIP.
2. A Unity Hub, afegeix des del disc la carpeta que conté Assets, Packages i ProjectSettings.
3. Obre el projecte i espera la instal·lació dels paquets i la importació dels recursos.
4. La primera importació obre automàticament `Assets/Scenes/DemoPlataformes.unity` i prem Play. Clica Game perquè rebi el teclat.

La primera obertura necessita Internet si els paquets no estan en memòria cau.
Unity genera Library; la mida del projecte en disc augmentarà.
Conserva els fitxers .meta: identifiquen els recursos i les seves referències.
Consulta el tutorial del mateix nom per als controls i les proves de la demo.

Per tornar a l’escena principal: Demo > Obrir escena principal. Les obertures posteriors respecten l’escena que estaves editant.
