using UnityEngine;

public class CoinPickup : MonoBehaviour
{
    public Transform visual;
    public float rotationSpeed = 90f;

    private bool collected;

    void Update()
    {
        // Gira només la part visible de la moneda; el trigger es manté al seu lloc.
        if (visual != null)
            visual.Rotate(Vector3.up, rotationSpeed * Time.deltaTime, Space.World);
    }

    // Unity avisa quan un collider entra al trigger; other identifica l'objecte que hi entra.
    void OnTriggerEnter(Collider other)
    {
        // Busca el script que porta el recompte al mateix objecte que ha entrat al trigger.
        CoinCollector collector = other.GetComponent<CoinCollector>();

        // Només pot recollir la moneda un objecte amb CoinCollector actiu; evita comptar-la dues
        // vegades.
        if (collected || collector == null || !collector.isActiveAndEnabled)
            return;

        collected = true;
        // Avisa el comptador del jugador abans d'amagar aquesta moneda.
        collector.CollectCoin();
        // Amaga l'objecte i desactiva els seus components després de recollir-lo.
        gameObject.SetActive(false);
    }
}
