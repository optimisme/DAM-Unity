using TMPro;
using UnityEngine;

public class CoinCollector : MonoBehaviour
{
    // Arrossega aquí el pare de les monedes; el farem servir per comptar-les.
    public Transform coinsRoot;
    // Referència al text de TextMeshPro que mostra el recompte a la pantalla.
    public TMP_Text counterText;
    public CoinDoor door;

    private int totalCoins;
    private int collectedCoins;

    void Start()
    {
        // Atura el component si falten les referències necessàries de l'Inspector.
        if (coinsRoot == null || counterText == null || door == null)
        {
            Debug.LogError("Assigna Coins Root, Counter Text i Door al Player.", this);
            enabled = false;
            return;
        }

        // Compta les monedes actives del nivell abans que el jugador en reculli cap.
        totalCoins = coinsRoot.GetComponentsInChildren<CoinPickup>().Length;

        if (totalCoins == 0)
        {
            Debug.LogError("Afegeix almenys una moneda activa dins de Coins.", this);
            enabled = false;
            return;
        }

        RefreshCounter();
    }

    public void CollectCoin()
    {
        // CoinPickup crida aquest mètode: suma una moneda i actualitza el text.
        collectedCoins++;
        RefreshCounter();

        // Quan s'han recollit totes les monedes, demana a CoinDoor que comenci a obrir-se.
        if (collectedCoins == totalCoins)
            door.Open();
    }

    void RefreshCounter()
    {
        // Insereix els valors de les variables dins del text que veurà el jugador.
        counterText.text = $"Monedes: {collectedCoins}/{totalCoins}";

        // Afegeix un avís al text quan el jugador ha completat la recollida.
        if (collectedCoins == totalCoins)
            counterText.text += "\nPorta oberta!";
    }
}
