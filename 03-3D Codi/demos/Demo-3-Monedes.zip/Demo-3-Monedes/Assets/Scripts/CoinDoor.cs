using UnityEngine;

// Aquest script necessita un Rigidbody al mateix objecte.
[RequireComponent(typeof(Rigidbody))]
public class CoinDoor : MonoBehaviour
{
    public float openHeight = 3.5f;
    public float speed = 2f;

    private Rigidbody body;
    private Vector3 openPosition;
    private bool opening;

    void Awake()
    {
        // Obtén el cos físic del mateix objecte per controlar-ne el moviment.
        body = GetComponent<Rigidbody>();
        // Calcula la posició final de la porta sumant l'altura d'obertura a la posició inicial.
        openPosition = body.position + Vector3.up * openHeight;
    }

    public void Open()
    {
        // Activa l'obertura; FixedUpdate farà avançar la porta gradualment.
        opening = true;
    }

    // Unity executa aquest mètode a intervals fixos per actualitzar la física.
    void FixedUpdate()
    {
        if (!opening)
            return;

        // Calcula el pas següent sense sobrepassar el destí; fixedDeltaTime és el temps del pas físic.
        Vector3 nextPosition = Vector3.MoveTowards(
            body.position, openPosition, speed * Time.fixedDeltaTime
        );

        // Mou el Rigidbody cinemàtic cap a la posició calculada durant l'actualització física.
        body.MovePosition(nextPosition);
    }
}
