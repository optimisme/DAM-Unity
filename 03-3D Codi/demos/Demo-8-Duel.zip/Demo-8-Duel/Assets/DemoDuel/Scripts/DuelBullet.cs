using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
public class DuelBullet : MonoBehaviour
{
    public float lifetime = 4;
    DuelFighter owner;
    bool spent;
    Material material;

    public void Launch(DuelFighter shooter, Vector3 direction, float speed, Color color)
    {
        // Recorda qui ha disparat per evitar que la bala li faci mal.
        owner = shooter;
        var bulletCollider = GetComponent<Collider>();
        // Ignora els xocs amb tots els colliders del personatge que dispara.
        foreach (var ownCollider in shooter.GetComponentsInChildren<Collider>())
            Physics.IgnoreCollision(bulletCollider, ownCollider);
        material = GetComponent<Renderer>().material;
        material.SetColor("_BaseColor", color);
        // Dona velocitat al cos físic de la bala; a partir d'aquí la física la mou.
        GetComponent<Rigidbody>().linearVelocity = direction * speed;
        // Programa l'eliminació de la bala si no impacta abans, per no acumular-ne indefinidament.
        Destroy(gameObject, lifetime);
    }

    // Unity avisa d'un xoc físic de la bala; collision conté la informació del contacte.
    void OnCollisionEnter(Collision collision)
    {
        if (spent) return;
        // Busca el lluitador també als pares, perquè el collider pot ser en un objecte fill.
        var fighter = collision.collider.GetComponentInParent<DuelFighter>();
        if (fighter == owner) return;
        // Marca la bala com a gastada per evitar que un altre contacte apliqui més d'un impacte.
        spent = true;
        // Resta vida si ha tocat un lluitador; si ha tocat un mur, només elimina la bala.
        if (fighter != null) fighter.TakeHit();
        Remove();
    }

    public void Remove()
    {
        // Marca la bala com a gastada per evitar que un altre contacte apliqui més d'un impacte.
        spent = true;
        // Desactiva la bala immediatament mentre espera que Destroy l'elimini.
        gameObject.SetActive(false);
        Destroy(gameObject);
    }

    void OnDestroy()
    {
        // Allibera la còpia del material perquè no quedi ocupant memòria.
        if (material != null) Destroy(material);
    }
}
