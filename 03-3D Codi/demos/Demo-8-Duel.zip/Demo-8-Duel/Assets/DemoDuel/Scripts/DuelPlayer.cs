using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController), typeof(DuelFighter))]
public class DuelPlayer : MonoBehaviour
{
    public Camera aimCamera;
    public float speed = 3.5f;
    CharacterController controller;
    DuelFighter fighter;
    float verticalSpeed;

    void Awake()
    {
        // Obtén el controlador del mateix objecte per moure'l respectant els colliders.
        controller = GetComponent<CharacterController>();
        fighter = GetComponent<DuelFighter>();
    }

    void Update()
    {
        if (fighter.game.IsOver) return;
        Vector2 input = Vector2.zero;
        var keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y++;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y--;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x--;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x++;
        }
        // Limita la intensitat del moviment per evitar anar més ràpid en diagonal.
        input = Vector2.ClampMagnitude(input, 1);
        if (controller.isGrounded && verticalSpeed < 0) verticalSpeed = -2;
        // Aplica la gravetat a la velocitat vertical; el Character Controller no ho fa sol.
        verticalSpeed -= 20 * Time.deltaTime;
        controller.Move(new Vector3(input.x * speed, verticalSpeed, input.y * speed) * Time.deltaTime);

        var mouse = Mouse.current;
        if (mouse == null) return;
        Vector2 screen = mouse.position.ReadValue();
        // Només apunta i dispara quan el punter és dins la vista de joc.
        if (!aimCamera.pixelRect.Contains(screen)) return;
        // Converteix la posició del ratolí a la pantalla en un raig que surt de la càmera.
        Ray ray = aimCamera.ScreenPointToRay(screen);
        // Crea un pla matemàtic horitzontal a l'altura del jugador per calcular on apunta.
        Plane aimPlane = new Plane(Vector3.up, new Vector3(0, transform.position.y, 0));
        // Calcula on el raig talla aquest pla; no és una comprovació contra colliders.
        if (!aimPlane.Raycast(ray, out float distance)) return;
        Vector3 direction = ray.GetPoint(distance) - transform.position;
        direction.y = 0;
        if (direction.sqrMagnitude < 0.01f) return;
        transform.rotation = Quaternion.LookRotation(direction);
        if (mouse.leftButton.isPressed) fighter.Fire(direction);
    }

    public void ResetMotion() => verticalSpeed = 0;
}
