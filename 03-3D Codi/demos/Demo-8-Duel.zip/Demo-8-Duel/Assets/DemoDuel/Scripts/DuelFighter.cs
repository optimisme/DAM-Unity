using UnityEngine;

public class DuelFighter : MonoBehaviour
{
    public DuelGame game;
    public DuelBullet bulletPrefab;
    public LayerMask wallsMask;
    public Color bulletColor = Color.cyan;
    public int maxLife = 3;
    public float bulletSpeed = 4.5f;
    public float shotInterval = 0.5f;
    public float muzzleOffset = 0.9f;
    public float bulletRadius = 0.15f;
    public int Life { get; private set; }
    float nextShot;

    public void ResetFighter()
    {
        Life = maxLife;
        nextShot = 0;
    }

    public bool Fire(Vector3 direction)
    {
        // No permet disparar si la ronda ha acabat, no queda vida o encara dura l'espera entre trets.
        if (game.IsOver || Life <= 0 || Time.time < nextShot) return false;
        direction.y = 0;
        if (direction.sqrMagnitude < 0.001f) return false;
        direction.Normalize();
        // Desa l'instant a partir del qual es podrà tornar a disparar.
        nextShot = Time.time + shotInterval;
        // Evita crear la bala a l'altra banda d'un mur molt proper.
        if (Physics.SphereCast(transform.position, bulletRadius, direction,
            out _, muzzleOffset, wallsMask, QueryTriggerInteraction.Ignore)) return false;
        // Crea una bala davant del personatge i l'orienta cap a la direcció del tret.
        DuelBullet bullet = Instantiate(bulletPrefab,
            transform.position + direction * muzzleOffset, Quaternion.LookRotation(direction));
        // Passa a la bala la referència de qui dispara, la direcció, la velocitat i el color.
        bullet.Launch(this, direction, bulletSpeed, bulletColor);
        return true;
    }

    public void TakeHit()
    {
        if (game.IsOver || Life <= 0) return;
        Life--;
        // Avisa el gestor de la ronda indicant quin lluitador s'ha quedat sense vida.
        if (Life == 0) game.Finish(this);
    }
}
