using UnityEngine;
using UnityEngine.InputSystem;

// Unity afegeix un Character Controller si l'objecte encara no en té.
[RequireComponent(typeof(CharacterController))]
public class GuardiaPlayer : MonoBehaviour
{
    public GuardiaGame game;
    public float speed = 3.5f;
    CharacterController controller;
    Vector3 start;
    float verticalSpeed;

    void Awake()
    {
        // Obtén el controlador del mateix objecte per moure'l respectant els colliders.
        controller = GetComponent<CharacterController>();
        start = transform.position;
    }

    void Update()
    {
        if (game.Won) return;
        Vector2 input = Vector2.zero;
        var keyboard = Keyboard.current;
        if (keyboard != null)
        {
            if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) input.y++;
            if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) input.y--;
            if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) input.x++;
            if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) input.x--;
        }
        // Limita la intensitat del moviment per evitar anar més ràpid en diagonal.
        input = Vector2.ClampMagnitude(input, 1);
        if (controller.isGrounded && verticalSpeed < 0) verticalSpeed = -2;
        // Aplica la gravetat a la velocitat vertical; el Character Controller no ho fa sol.
        verticalSpeed += -20 * Time.deltaTime;
        controller.Move(new Vector3(input.x * speed, verticalSpeed, input.y * speed) * Time.deltaTime);
        if (transform.position.y < -5) game.ResetRound(true);
    }

    public void Respawn()
    {
        // Desactiva temporalment el controlador per recol·locar el personatge directament.
        controller.enabled = false;
        transform.position = start;
        controller.enabled = true;
        verticalSpeed = 0;
    }
}
