using System.Collections.Generic;
using UnityEngine;

// Unity afegeix un Character Controller si l'objecte encara no en té.
[RequireComponent(typeof(CharacterController))]
public class GuardiaBrain : MonoBehaviour
{
    // Tres comportaments possibles: patrullar, perseguir i tornar al recorregut.
    public enum GuardState { Patrol, Chase, Return }
    public GuardiaPlayer player;
    public GuardiaGame game;
    public Transform[] points;
    public Renderer body;
    // Selecciona a l'Inspector les capes dels murs que poden bloquejar la visió.
    public LayerMask wallsMask;
    public float patrolSpeed = 1.4f;
    public float chaseSpeed = 2.2f;
    public float viewDistance = 5;
    public float viewAngle = 100;
    public float memoryTime = 2;
    public float catchDistance = 1.05f;
    public GuardState State { get; private set; }
    public bool SeesPlayer { get; private set; }

    CharacterController controller;
    Material material;
    int nextPoint;
    float lostTime;
    Vector3 lastSeen;
    // Guarda el camí de la persecució per poder tornar pels mateixos llocs.
    readonly List<Vector3> trail = new List<Vector3>();

    void Awake()
    {
        // Obtén el controlador del mateix objecte per moure'l respectant els colliders.
        controller = GetComponent<CharacterController>();
        material = body.material;
    }

    void OnDestroy()
    {
        // Allibera la còpia del material perquè no quedi ocupant memòria.
        if (material != null) Destroy(material);
    }

    public void ResetGuard()
    {
        // Desactiva temporalment el controlador per recol·locar el personatge directament.
        controller.enabled = false;
        transform.position = points[0].position;
        controller.enabled = true;
        // Tria el següent punt; el mòdul (%) manté l'índex dins de la llista.
        nextPoint = 1 % points.Length;
        Face(points[nextPoint].position - transform.position, true);
        lostTime = 0;
        SeesPlayer = false;
        trail.Clear();
        SetState(GuardState.Patrol);
    }

    public bool CanSeePlayer()
    {
        Vector3 delta = player.transform.position - transform.position;
        delta.y = 0;
        // Descarta el jugador si queda més lluny de l'abast de visió.
        if (delta.magnitude > viewDistance) return false;
        // Comprova si és dins del con: la meitat de l'angle queda a cada costat de la mirada.
        if (delta.sqrMagnitude > 0.001f && Vector3.Angle(transform.forward, delta) > viewAngle * 0.5f)
            return false;
        Vector3 eye = transform.position + Vector3.up * 0.3f;
        Vector3 target = player.transform.position + Vector3.up * 0.3f;
        // El veu si no hi ha cap mur entre els ulls i el jugador; els triggers no tapen la vista.
        return !Physics.Linecast(eye, target, wallsMask, QueryTriggerInteraction.Ignore);
    }

    void Update()
    {
        if (game.Won) return;
        // Actualitza la detecció abans de decidir si patrulla, persegueix o torna.
        SeesPlayer = CanSeePlayer();
        if (SeesPlayer)
        {
            if (State == GuardState.Patrol)
            {
                trail.Clear();
                trail.Add(transform.position);
            }
            // Si el veu mentre torna, conserva el camí per poder desfer-lo després.
            SetState(GuardState.Chase);
            lostTime = 0;
            // Recorda on ha vist el jugador per últim cop per continuar-hi anant si el perd de vista.
            lastSeen = player.transform.position;
            lastSeen.y = transform.position.y;
        }
        else if (State == GuardState.Chase)
        {
            // Compta quant temps fa que no el veu; en esgotar la memòria, comença el retorn.
            lostTime += Time.deltaTime;
            if (lostTime >= memoryTime) SetState(GuardState.Return);
        }

        if (State == GuardState.Patrol)
        {
            if (WalkTo(points[nextPoint].position, patrolSpeed))
                // Avança al punt següent i torna al primer després de l'últim.
                nextPoint = (nextPoint + 1) % points.Length;
        }
        else if (State == GuardState.Chase)
        {
            WalkTo(lastSeen, chaseSpeed);
            // Desa posicions separades almenys 0.3 unitats per no omplir la llista a cada petit
            // moviment.
            if (trail.Count == 0 || FlatDistance(transform.position, trail[trail.Count - 1]) >= 0.3f)
                trail.Add(transform.position);
            Vector3 eye = transform.position + Vector3.up * 0.3f;
            Vector3 target = player.transform.position + Vector3.up * 0.3f;
            // Només atrapa el jugador si és prou a prop i cap mur els separa.
            if (FlatDistance(transform.position, player.transform.position) < catchDistance &&
                !Physics.Linecast(eye, target, wallsMask, QueryTriggerInteraction.Ignore))
                game.ResetRound(true);
        }
        else
        {
            // Recorre en ordre invers les posicions per on realment ha passat.
            if (trail.Count == 0) SetState(GuardState.Patrol);
            else if (WalkTo(trail[trail.Count - 1], patrolSpeed)) trail.RemoveAt(trail.Count - 1);
        }
    }

    bool WalkTo(Vector3 target, float speed)
    {
        Vector3 delta = target - transform.position;
        delta.y = 0;
        if (delta.magnitude < 0.06f) return true;
        Face(delta, false);
        // Limita el pas a la velocitat indicada i evita sobrepassar el punt de destí.
        Vector3 movement = Vector3.ClampMagnitude(delta, speed * Time.deltaTime);
        // Afegeix un petit desplaçament cap avall per mantenir el contacte amb el terra.
        movement.y = -2 * Time.deltaTime;
        controller.Move(movement);
        return false;
    }

    void Face(Vector3 direction, bool instant)
    {
        direction.y = 0;
        if (direction.sqrMagnitude < 0.001f) return;
        // Calcula la rotació necessària per mirar cap a la direcció del moviment.
        Quaternion target = Quaternion.LookRotation(direction);
        transform.rotation = instant ? target : Quaternion.RotateTowards(transform.rotation, target, 540 * Time.deltaTime);
    }

    void SetState(GuardState state)
    {
        State = state;
        Color color = state == GuardState.Patrol ? new Color(0.15f, 0.55f, 1) :
                      state == GuardState.Chase ? new Color(1, 0.15f, 0.1f) : new Color(1, 0.8f, 0.1f);
        material.SetColor("_BaseColor", color);
    }

    static float FlatDistance(Vector3 a, Vector3 b)
    {
        // Ignora l'altura: calcula la distància horitzontal sobre el pla XZ.
        a.y = b.y = 0;
        return Vector3.Distance(a, b);
    }
}
