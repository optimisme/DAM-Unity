using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class GuardiaGame : MonoBehaviour
{
    public GuardiaPlayer player;
    public GuardiaBrain guard;
    public GameObject key;
    public Transform door;
    public Collider doorCollider;
    public Transform exit;
    public TMP_Text status;
    public bool Won { get; private set; }
    public bool HasKey { get; private set; }
    Vector3 closedPosition;
    float messageUntil;

    void Start()
    {
        closedPosition = door.position;
        ResetRound(false);
    }

    void Update()
    {
        if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
            ResetRound(false);
        if (!Won)
        {
            // Recull la clau per proximitat; aquest cas no depèn d'un trigger.
            if (!HasKey && FlatDistance(player.transform.position, key.transform.position) < 1)
            {
                HasKey = true;
                key.SetActive(false);
            }
            Vector3 target = closedPosition + (HasKey ? Vector3.up * 2.5f : Vector3.zero);
            door.position = Vector3.MoveTowards(door.position, target, 3 * Time.deltaTime);
            bool open = HasKey && Vector3.Distance(door.position, target) < 0.01f;
            // Retira el bloqueig físic quan la porta ja ha arribat a la posició oberta.
            doorCollider.enabled = !open;
            if (open && FlatDistance(player.transform.position, exit.position) < 0.65f) Won = true;
        }
        string state = guard.State == GuardiaBrain.GuardState.Patrol ? "Patrulla (blau)" :
                       guard.State == GuardiaBrain.GuardState.Chase ? "Persecució (vermell)" : "Retorn (groc)";
        status.text = Won ? "Has escapat! Prem R per tornar a començar." :
            (Time.time < messageUntil ? "T'ha atrapat! Tornes a l'inici.\n" : "") +
            "Vigilant: " + state + "\n" + (HasKey ? "Clau recollida: arriba a la sortida verda." : "Busca la clau daurada i evita el vigilant.");
    }

    public void ResetRound(bool caught)
    {
        Won = false;
        HasKey = false;
        key.SetActive(true);
        door.position = closedPosition;
        doorCollider.enabled = true;
        player.Respawn();
        guard.ResetGuard();
        // Actualitza la informació física dels colliders amb els canvis de posició.
        Physics.SyncTransforms();
        // Si el vigilant l'ha atrapat, manté el missatge visible durant dos segons.
        messageUntil = caught ? Time.time + 2 : 0;
    }

    static float FlatDistance(Vector3 a, Vector3 b)
    {
        // Ignora l'altura: calcula la distància horitzontal sobre el pla XZ.
        a.y = b.y = 0;
        return Vector3.Distance(a, b);
    }
}
