using UnityEngine;
using UnityEngine.InputSystem;

public class GameManager : MonoBehaviour
{
    [SerializeField] private MovimentPilota ball;
    [SerializeField] private Transform player;

    private void Awake()
    {
        // Find by GameObject name like original code
        if (!ball)
        {
            var go = GameObject.Find("Pilota");
            if (go) ball = go.GetComponent<MovimentPilota>();
            else Debug.LogWarning("[GameManager] No GameObject named 'Pilota' found");
        }
        if (!player)
        {
            var go = GameObject.Find("Jugador");
            if (go) player = go.transform;
            else Debug.LogWarning("[GameManager] No GameObject named 'Jugador' found");
        }
    }

    private void Start()
    {
        RestartGame();
    }

    private void Update()
    {
        if (GameState.gameOver && Keyboard.current?.spaceKey.wasPressedThisFrame == true)
        {
            RestartGame();
        }
    }

    public void RestartGame()
    {
        GameState.Reset();
        CenterPlayer();
        if (ball) ball.ResetBall();
    }

    private void CenterPlayer()
    {
        if (player)
        {
            var pos = player.position;
            pos.x = 0f;
            player.position = pos;
        }
    }
}