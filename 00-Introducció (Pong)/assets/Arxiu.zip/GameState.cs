using UnityEngine;

public static class GameState
{
    public static float speedFactor = 1f;
    public static int points = 0;
    public static bool gameOver = false;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetOnLoad()
    {
        speedFactor = 1f;
        points = 0;
        gameOver = false;
    }

    public static void Reset()
    {
        speedFactor = 1f;
        points = 0;
        gameOver = false;
    }
}
