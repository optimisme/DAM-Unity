using UnityEngine;
using UnityEngine.InputSystem;

public class MovimentJugador : MonoBehaviour
{
    [SerializeField] private float baseSpeed = 5f;
    [SerializeField] private Transform leftWall;
    [SerializeField] private Transform rightWall;

    private Rigidbody2D rb;
    private Collider2D playerCollider;
    private float leftBound, rightBound;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerCollider = GetComponent<Collider2D>();
        
        // Find walls if not assigned - keeping original names
        if (!leftWall) leftWall = GameObject.Find("Mur esquerra")?.transform;
        if (!rightWall) rightWall = GameObject.Find("Mur dreta")?.transform;
        
        CalculateBounds();
        SetupRigidbody();
    }

    private void SetupRigidbody()
    {
        rb.gravityScale = 0f;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation | RigidbodyConstraints2D.FreezePositionY;
    }

    private void CalculateBounds()
    {
        if (leftWall && rightWall && playerCollider)
        {
            float halfWidth = playerCollider.bounds.extents.x;
            leftBound = leftWall.GetComponent<Collider2D>().bounds.max.x + halfWidth;
            rightBound = rightWall.GetComponent<Collider2D>().bounds.min.x - halfWidth;
        }
    }

    private void FixedUpdate()
    {
        if (GameState.gameOver) return;

        float input = GetMovementInput();
        float velocity = baseSpeed * GameState.speedFactor * input;
        
        rb.linearVelocity = new Vector2(velocity, 0f);
        ClampPosition();
    }

    private float GetMovementInput()
    {
        float input = 0f;
        
        if (Keyboard.current?.leftArrowKey.isPressed == true || 
            Keyboard.current?.aKey.isPressed == true)
            input -= 1f;
            
        if (Keyboard.current?.rightArrowKey.isPressed == true || 
            Keyboard.current?.dKey.isPressed == true)
            input += 1f;
            
        return input;
    }

    private void ClampPosition()
    {
        if (leftWall && rightWall)
        {
            var pos = rb.position;
            pos.x = Mathf.Clamp(pos.x, leftBound, rightBound);
            rb.position = pos;
        }
    }
}