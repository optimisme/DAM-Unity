using UnityEngine;

public class MovimentPilota : MonoBehaviour
{
    [SerializeField] private float initialSpeed = 5f;
    [SerializeField] private float speedIncrement = 0.5f;

    private Rigidbody2D rb;
    private float currentSpeed;
    private Vector2 direction;

    // Diagonal directions (45 degrees)
    private static readonly Vector2 UP_LEFT = new Vector2(-1, 1).normalized;
    private static readonly Vector2 UP_RIGHT = new Vector2(1, 1).normalized;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        currentSpeed = initialSpeed;
    }

    private void Start()
    {
        SetupRigidbody();
        ResetBall();
    }

    private void SetupRigidbody()
    {
        rb.gravityScale = 0f;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    private void FixedUpdate()
    {
        if (!GameState.gameOver)
        {
            // Maintain constant speed
            rb.linearVelocity = direction * currentSpeed;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Vector2 normal = collision.contacts[0].normal;
        
        // Reflect direction based on collision normal
        if (Mathf.Abs(normal.x) > Mathf.Abs(normal.y))
            direction = new Vector2(-direction.x, direction.y); // Horizontal bounce
        else
            direction = new Vector2(direction.x, -direction.y); // Vertical bounce
            
        direction = direction.normalized;

        // Check if hit player - keeping original name check
        if (collision.gameObject.name == "Jugador" || collision.collider.transform.root.name == "Jugador")
        {
            OnPlayerHit();
        }
    }

    private void OnPlayerHit()
    {
        currentSpeed += speedIncrement;
        GameState.points++;
        GameState.speedFactor = Mathf.Max(1f, currentSpeed / initialSpeed);
    }

    private void OnBecameInvisible()
    {
        // Ball left screen - game over
        GameState.gameOver = true;
        rb.linearVelocity = Vector2.zero;
    }

    public void ResetBall()
    {
        transform.position = Vector3.zero;
        currentSpeed = initialSpeed;
        
        // Random initial direction (up-left or up-right)
        direction = Random.value < 0.5f ? UP_LEFT : UP_RIGHT;
        
        if (rb) rb.linearVelocity = direction * currentSpeed;
    }
}