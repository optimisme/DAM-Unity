using UnityEngine;
using TMPro;

public class UIHUD : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI scoreText;
    [SerializeField] private TextMeshProUGUI gameOverText;
    
    private int lastPoints = -1;
    private float lastSpeedFactor = -1f;
    private bool lastGameOverState = false;

    private void Awake()
    {
        // Auto-find UI elements by name like original code
        if (!scoreText) scoreText = GameObject.Find("Punts")?.GetComponent<TextMeshProUGUI>();
        if (!gameOverText) gameOverText = GameObject.Find("GameOver")?.GetComponent<TextMeshProUGUI>();
        
        if (gameOverText) gameOverText.gameObject.SetActive(false);
    }

    private void Update()
    {
        UpdateScoreDisplay();
        UpdateGameOverDisplay();
    }

    private void UpdateScoreDisplay()
    {
        if (scoreText && (GameState.points != lastPoints || GameState.speedFactor != lastSpeedFactor))
        {
            scoreText.text = $"Factor: x{GameState.speedFactor:F2} - Punts: {GameState.points}";
            lastPoints = GameState.points;
            lastSpeedFactor = GameState.speedFactor;
        }
    }

    private void UpdateGameOverDisplay()
    {
        if (gameOverText && GameState.gameOver != lastGameOverState)
        {
            gameOverText.gameObject.SetActive(GameState.gameOver);
            lastGameOverState = GameState.gameOver;
        }
    }
}